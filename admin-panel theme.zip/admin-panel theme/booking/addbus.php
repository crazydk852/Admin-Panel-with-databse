<?php
include_once("config.php");
session_start();

$admin_id = $_SESSION['admin_id'];

if (isset($_POST['submit'])) {
	
    $bus_number = $_POST['bus_number'];
    $bus_type = $_POST['bus_type'];
    $bus_drivename = $_POST['bus_drivename'];

    $current_date = date("Y-m-d H:i:s");

    $select = mysqli_query($con, "SELECT * FROM bus_master WHERE bus_number = '$bus_number'");
    $row = mysqli_fetch_assoc($select);

    if ($row) {
        echo "<script>
                alert('Bus Number already registered!');
                window.location.href = 'addbus.php';
              </script>";
        exit();
    } else {
        $select = "INSERT INTO bus_master(bus_number, bus_type, bus_drivename, bus_datetime) VALUES  ('$bus_number','$bus_type','$bus_drivename','$current_date')";

        if (mysqli_query($con, $select)) {
            header('Location: dashboard.php');
            exit();
        } else {
            echo "Error updating record: " . mysqli_error($con);
        }
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>
<form method="post">
  <div>
    <h1>Add Bus Details</h1>
    <br />
    <label><b>Bus Number</b></label>
    <input type="text" name="bus_number">
    <br />
    <label><b>Bus Type</b></label>
    <select type="text" name="bus_type" style="margin-right: 73px;">
      <option value="">-select-</option>
      <option value="ac">AC</option>
      <option value="nonac">NON AC</option>
    </select>
    <br />
    <label><b>Driver Name</b></label>
    <input type="text" name="bus_drivename">
    <br />
    <input type="submit" name="submit" value="Submit">
    <a href="dashboard.php" class="btn btn-primary">Back</a>
  </div>
</form>
</body>
</html>