<?php
include_once("config.php");
session_start();

$admin_id = $_SESSION['admin_id'];

if (isset($_POST['submit'])) {
    $tour_date = $_POST['tour_date'];
    $tour_place = $_POST['tour_place'];
    $tour_daynight = $_POST['tour_daynight'];
    $tour_price = $_POST['tour_price'];
    $tour_description = $_POST['tour_description'];

    $current_date = date("Y-m-d H:i:s");
    
        $select = "INSERT INTO tour_master(tour_date, tour_place, tour_daynight, tour_price, tour_description, tour_datetime) VALUES  ('$tour_date', '$tour_place', '$tour_daynight', '$tour_price', '$tour_description', '$current_date')";

        if (mysqli_query($con, $select)) {
            header('Location: dashboard.php');
            exit();
        } else {
            echo "Error updating record: " . mysqli_error($con);
        }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>
<form method="post">
  <div>
    <h1>Add Tour Details</h1>
    <br />
    <label><b>Date</b></label>
    <input type="date" name="tour_date">
    <br />
    <label><b>Place</b></label>
    <textarea type="text" name="tour_place"></textarea>
    <br />
    <label><b>Day / Night</b></label>
    <input type="text" name="tour_daynight">
    <br />
    <label><b>Price</b></label>
    <input type="text" name="tour_price">
    <br />
    <label><b>Description</b></label>
    <textarea type="text" name="tour_description"></textarea>
    <br />
    <input type="submit" name="submit" value="Submit">
    <a href="dashboard.php" class="btn btn-primary">Back</a>
  </div>
</form>
</body>
</html>