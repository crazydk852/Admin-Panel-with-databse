<?php
include('config.php');
include('sismaster.php');
$action = $_REQUEST['action'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript">
function formaction(ID,ID1)
{
	window.location = "bus.php?action=set&act="+ ID + "&bus="+ ID1;
}
function formaction1(ID)
{
	window.location = "bus.php?action=set&act="+ ID;
}
function confirmDelete()
{
    return confirm("Are you sure you want to delete this record?");
}
</script>
</head>
<body>
<?php if($action == "list" || $action == "edit" ){  ?>
<a  href="javascript:formaction1(<?php echo "1";?>)" class="btn btn-primary">Add new </a>&nbsp;<a  href="dashboard.php" class="btn btn-primary">Back </a>
<?php } ?>
<?php if($action == "add") {?>
<form method="post">
  <div>
    <h1>Add Bus Details</h1>
    <br />
    <label><b>Bus Number</b></label>
    <input type="text" name="bus_number">
    <br />
    <label><b>Bus Type</b></label>
    <select type="text" name="bus_type" style="margin-right: 73px;">
      <option value="">-select-</option>
      <option value="ac">AC</option>
      <option value="nonac">NON AC</option>
    </select>
    <br />
    <label><b>Driver Name</b></label>
    <input type="text" name="bus_drivename">
    <br />
    <input type="submit" name="submit" value="Submit">
    <a href="bus.php?action=list" class="btn btn-primary">Back</a>
  </div>
</form>
<?php
if (isset($_POST['submit'])) {
    $bus_number = $_POST['bus_number'];
    $bus_type = $_POST['bus_type'];
    $bus_drivename = $_POST['bus_drivename'];
	
    $current_date = date("Y-m-d H:i:s");

    $select = mysqli_query($con, "SELECT * FROM bus_master WHERE bus_number = '$bus_number'");
    $row = mysqli_fetch_assoc($select);

    if ($row)
	{
        echo "<script>
                alert('Bus Number already registered!');
                window.location.href = 'addbus.php';
              </script>";
        exit();
    }
	else
	{
        $sql = "INSERT INTO bus_master(bus_number, bus_type, bus_drivename, bus_datetime) VALUES  ('$bus_number','$bus_type','$bus_drivename','$current_date')";
       
        mysqli_query($con, $sql);
		$bus_id = mysqli_insert_id($con);
		
		echo "<script type='text/javascript'>";
		echo "window.location='bus.php?action=list'";
		echo "</script>";
    }
}
?>
<?php }if($action == "list") {?>
<table border="1">
  <thead>
    <tr>
      <th style="text-align:center;">No</th>
      <th>Bus Number</th>
      <th>Bus Type</th>
      <th>Driver Name</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php
	$no="0";
    $select = mysqli_query($con,"SELECT * FROM bus_master ORDER BY bus_id ASC");
	while($row=mysqli_fetch_array($select))
	{ ?>
    <tr>
      <td><?php echo $no=$no+1; ?></td>
      <td><?php echo $row['bus_number']; ?></td>
      <td><?php echo $row['bus_type']; ?></td>
      <td><?php echo $row['bus_drivename']; ?></td>
      <td><a href="javascript:formaction(<?php echo "2" ?>,<?php echo $row['bus_id']; ?>)">Update</a> <a href="javascript:if(confirmDelete())formaction(<?php echo "3"; ?>,<?php echo $row['bus_id']; ?>)">Delete</a></td>
    </tr>
    <?php }?>
  </tbody>
</table>
<?php }if($action == "edit") {?>
<?php 
    $select=mysqli_query($con,"SELECT * FROM bus_master where bus_id='$bus_id'");
    while($row=mysqli_fetch_array($select))
    {
    ?>
<form method="post">
  <div>
    <h1>Registration Form</h1>
    <label><b>Name</b></label>
    <input type="text" name="bus_name" value="<?php echo $row["bus_number"]; ?>">
    <br />
    <label><b>Price</b></label>
    <select type="text" name="bus_type" style="margin-right: 73px;">
      <option value="<?php echo $row["bus_type"]; ?>"><?php echo $row["bus_type"]; ?></option>
      <option value="ac">AC</option>
      <option value="nonac">NON AC</option>
    </select>
    <br />
    <label><b>Code</b></label>
    <input type="text" name="bus_code" value="<?php echo $row["bus_drivename"]; ?>">
    <br />
    <input type="submit" name="submit" value="Submit">
    <a href="bus.php?action=list" class="btn btn-primary">Back</a> </div>
</form>
<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $bus_name= $_POST["bus_number"];
	$bus_price= $_POST["bus_type"];
	$bus_code= $_POST["bus_drivename"];
	
   $sql = "UPDATE bus_master SET bus_number='$bus_number', bus_type='$bus_type', bus_drivename='$bus_drivename'  WHERE bus_id='$bus_id'";
	mysqli_query($con,$sql);
	
	echo "<script type='text/javascript'>";
	echo "window.location='bus.php?action=list'";
	echo "</script>";
}
?>
<?php }?>
<?php } 
if($action == "delete")
{ 
	$delete = mysqli_query($con,"delete from bus_master where bus_id  = '$bus_id'");
	
	echo "<script type='text/javascript'>";
	echo "window.location='bus.php?action=list'";
	echo "</script>";
}
?>
<?php if($action != "list") {?>
<?php } 
if($action == 'set') 
{	
	$act = $_REQUEST['act'];
	$actionvalue = "";
	
	$bus_id = $_REQUEST['bus'];
	if($bus_id != NULL){ $_SESSION['bus_id'] = $bus_id; }
	
	if($act == "1"){ $actionvalue = "add"; }
	if($act == "2"){ $actionvalue = "edit"; }
	if($act == "3"){ $actionvalue = "delete"; }
	if($act == "4"){ $actionvalue = "view"; }
	if($act == "5"){ $actionvalue = "list"; }
	
	if($act == "1")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='bus.php?action=add'";
		echo "</script>";
	}
	if($act == "2")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='bus.php?action=edit'";
		echo "</script>";
	}
	if($act == "3")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='bus.php?action=delete'";
		echo "</script>";
	}
	if($act == "5")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='bus.php?action=list'";
		echo "</script>";
	}
}
?>
</body>
</html>