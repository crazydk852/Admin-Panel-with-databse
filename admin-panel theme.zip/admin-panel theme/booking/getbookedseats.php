<?php
include('config.php');
include('sismaster.php');

// Fetch booked seats from the database
$tourbooking_id = 1; // Replace with the actual tourbooking_id or fetch it from your session or wherever applicable
$bookedSeatsQuery = "SELECT busseats_number FROM busseats_master WHERE tour_id = '$tour_id'";
$bookedSeatsResult = mysqli_query($con, $bookedSeatsQuery);

$bookedSeats = array();
while ($row = mysqli_fetch_assoc($bookedSeatsResult)) {
    $bookedSeats[] = $row['busseats_number'];
}

// Return booked seats as JSON
header('Content-Type: application/json');
echo json_encode(['bookedSeats' => $bookedSeats]);

// Close the database connection
$con->close();
exit;
?>
