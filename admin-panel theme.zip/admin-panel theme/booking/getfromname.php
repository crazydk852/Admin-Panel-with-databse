<?php
include('config.php');
include('sismaster.php');

// Get the user input
$query = $_POST['query'];

$select = mysqli_query($con,"SELECT tour_from FROM tour_master WHERE tour_from LIKE '%$query%'");
while($row=mysqli_fetch_array($select))
{
	echo "<option>" . $row['tour_from'] . "</option>";
}
$con->close();
?>
