<?php
 	include_once("config.php");
	include('sismaster.php');
	$action = '';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script type="text/javascript">
function formaction(ID,ID1)
{
	window.location = "tour-booking.php?action=set&act="+ ID + "&tour="+ ID1;
}
</script>
<script>
function getfromname() {
  var input = $("#from").val();
  if (input.length >= 3) { // Only start searching after 3 characters
    $.ajax({
      type: "POST",
      url: "getfromname.php", // Replace with the actual server-side script
      data: { query: input },
      success: function(response) {
        $("#suggestionBox").html(response);
      }
    });
  } else {
    $("#suggestionBox").html(""); // Clear suggestions if input is less than 3 characters
  }
}
</script>
</head>
<body>
<form method="post">
  <div>
    <label><b>From</b></label>
    <input type="text" name="from" id="from" oninput="getfromname()">
    <div id="suggestionBox"> </div>
    <label><b>To</b></label>
    <input type="text" name="to">
    <label><b>Start Date</b></label>
    <input type="date" name="sdate">
    <label><b>End Date</b></label>
    <input type="date" name="edate"> 
    <input type="submit" name="submit" value="Submit">
    <a href="dashboard.php" class="btn btn-primary">Go to Profile</a>
  </div>
</form>
<?php
if (isset($_POST['submit'])) {
    $sdate = $_POST['sdate'];
    $edate = $_POST['edate'];
	
?>
<table border="1">
  <thead>
    <tr>
      <th style="text-align:center;">No</th>
      <th>Place</th>
      <th>Day / Night</th>
      <th>Price</th>
      <th>Description</th>
      <th>Tour Date</th>
      <th>Bus Number</th>
      <th>Booking</th>
    </tr>
  </thead>
  <tbody>
    <?php
	$no="0";
    $select = mysqli_query($con,"SELECT * FROM tour_master WHERE tour_date BETWEEN '$sdate' AND '$edate' ORDER BY tour_id");
	while($row=mysqli_fetch_array($select))
	{ 
		$bus_id = $row['bus_id'];
	?>
    <tr>
      <td><?php echo $no=$no+1; ?></td>
      <td><?php echo $row['tour_place']; ?></td>
      <td><?php echo $row['tour_daynight']; ?></td>
      <td><?php echo $row['tour_price']; ?></td>
      <td><?php echo $row['tour_description']; ?></td>
      <td><?php echo $row['tour_date']; ?></td>
      <td><?php echo getbusnumberfrombusid($row['bus_id']); ?></td>
      <td><a href="javascript:formaction(<?php echo "2" ?>,<?php echo $row['tour_id']; ?>)">Book Now</a></td>
    </tr>
    <?php }?>
  </tbody>
</table>
<?php } 
if($action == 'set') 
{	
	$act = $_REQUEST['act'];
	$actionvalue = "";
	
	$tour_id = $_REQUEST['tour'];
	if($tour_id != NULL){ $_SESSION['tour_id'] = $tour_id; }
	
	if($act == "2"){ $actionvalue = "booking"; }
	
	if($act == "2")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='tour-booking.php?action=edit'";
		echo "</script>";
	}
}
?>
</body>
</html>