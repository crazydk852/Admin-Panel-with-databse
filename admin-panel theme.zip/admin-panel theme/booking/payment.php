<?php
include('config.php');
include('sismaster.php');
$action = $_REQUEST['action'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript">
function formaction(ID,ID1)
{
	window.location = "tour-booking.php?action=set&act="+ ID + "&tour="+ ID1;
}
function formaction2(ID,ID1)
{
	window.location = "payment.php?action=set&act="+ ID + "&tour="+ ID1;
}
</script>
</head>
<body>
<?php if($action == "list" || $action == "edit" ){  ?>
<a  href="javascript:formaction1(<?php echo "1";?>)" class="btn btn-primary">Add new </a>&nbsp;<a  href="dashboard.php" class="btn btn-primary">Back </a>
<?php } ?>
<?php if($action == "payment") {?>
<?php 
    $select=mysqli_query($con,"SELECT * FROM tourbooking_master where tourbooking_id='$tourbooking_id'");
    while($row=mysqli_fetch_array($select))
    {
    ?>
<form method="post">
  <label>Payable Amount</label>
  <input type="text" name="payment_card" value="<?php echo $row['tourbooking_price']; ?>"readonly>
  <br />
  <label>Card Number:</label>
  <input type="text" name="payment_card" placeholder="1234 5678 9012 3456" required>
  <br />
  <label>Expiry Date:</label>
  <input type="text" name="payment_edate" placeholder="MM/YYYY" required>
  <br />
  <label>CVV:</label>
  <input type="text" name="payment_cvv" placeholder="123" required>
  <br />
  <label>Card Holder Name:</label>
  <input type="text" name="payment_name" placeholder="Your Name" required>
  <br />
  <input type="text" name="payment_status" value="Booked" hidden>
  <input type="submit" name="submit" value="Submit">
  <a href="index.php" class="btn btn-primary">cancel</a>
</form>
<?php
if (isset($_POST['submit'])) {
    $payment_card = $_POST['payment_card'];
    $payment_edate = $_POST['payment_edate'];
    $payment_cvv = $_POST['payment_cvv'];
    $payment_name = $_POST['payment_name'];
    $payment_status = $_POST['payment_status'];
	$admin_id = $_SESSION['admin_id'];
	
    $current_date = date("Y-m-d H:i:s");

   $sql = "INSERT INTO payment_master(tourbooking_id, payment_card, payment_edate, payment_cvv, payment_name, payment_status, admin_id, payment_datetime) VALUES ('$tourbooking_id', '$payment_card', '$payment_edate', '$payment_cvv', '$payment_name', '$payment_status', '$admin_id', '$current_date')";
       
        mysqli_query($con, $sql);
		$payment_id = mysqli_insert_id($con);
		
		 $sql1 = "UPDATE tourbooking_master SET tourbooking_status='$payment_status', admin_id='$admin_id', tourbooking_datetime='$current_date' WHERE tourbooking_id='$tourbooking_id'";
       
        mysqli_query($con, $sql1);
		$tourbooking_id = mysqli_insert_id($con);
		
		echo "<script type='text/javascript'>";
		echo "window.location='dashboard.php'";
		echo "</script>";
}
?>
<?php } }?>
<?php if($action != "list") {?>
<?php } 
if($action == 'set') 
{	
	$act = $_REQUEST['act'];
	$actionvalue = "";
	
	$tour_id = $_REQUEST['tour'];
	if($tour_id != NULL){ $_SESSION['tour_id'] = $tour_id; }
	
	$tourbooking_id = $_REQUEST['tour'];
	if($tourbooking_id != NULL){ $_SESSION['tourbooking_id'] = $tourbooking_id; }
	
	if($act == "1"){ $actionvalue = "add"; }
	if($act == "2"){ $actionvalue = "edit"; }
	if($act == "3"){ $actionvalue = "delete"; }
	if($act == "4"){ $actionvalue = "view"; }
	if($act == "5"){ $actionvalue = "list"; }
	if($act == "6"){ $actionvalue = "cbooking"; }
	if($act == "7"){ $actionvalue = "payment"; }
	
	if($act == "1")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='tour-booking.php?action=add'";
		echo "</script>";
	}
	if($act == "7")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='payment.php?action=payment'";
		echo "</script>";
	}
}
?>
</body>
</html>