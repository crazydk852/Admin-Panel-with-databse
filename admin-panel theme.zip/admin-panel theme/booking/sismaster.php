<?php 
session_start();
if(isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']))
{	
	if(isset($_SESSION['category_id']) && !empty($_SESSION['category_id'])) { $category_id = $_SESSION['category_id']; }
	if(isset($_SESSION['bus_id']) && !empty($_SESSION['bus_id'])) { $bus_id = $_SESSION['bus_id']; }
	if(isset($_SESSION['tour_id']) && !empty($_SESSION['tour_id'])) { $tour_id = $_SESSION['tour_id']; }
	if(isset($_SESSION['tourbooking_id']) && !empty($_SESSION['tourbooking_id'])) { $tourbooking_id = $_SESSION['tourbooking_id']; }
	if(isset($_SESSION['busseats_id']) && !empty($_SESSION['busseats_id'])) { $busseats_id = $_SESSION['busseats_id']; }
	if(isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id'])) { $admin_id = $_SESSION['admin_id']; }
	if(isset($_SESSION['payment_id']) && !empty($_SESSION['payment_id'])) { $payment_id = $_SESSION['payment_id']; }
}
else 
{
	echo "<script type='text/javascript'>";
	echo "window.location='logout.php'";
	echo "</script>";
} 
?>
