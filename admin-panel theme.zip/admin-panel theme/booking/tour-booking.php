<?php
include('config.php');
include('sismaster.php');
$action = $_REQUEST['action'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script type="text/javascript">
function formaction(ID,ID1)
{
	window.location = "tour-booking.php?action=set&act="+ ID + "&tour="+ ID1;
}
function formaction2(ID,ID1)
{
	window.location = "payment.php?action=set&act="+ ID + "&tour="+ ID1;
}
function formaction1(ID)
{
	window.location = "tour-booking.php?action=set&act="+ ID;
}
function confirmDelete()
{
    return confirm("Are you sure want to delete this record?");
}
function generateBookingNumber()
{
	const prefix = "SMJU";
	const randomNumber = Math.floor(Math.random() * 1000000);
	const bookingNumber = `${prefix}${randomNumber}`;
	
	document.getElementById("bookingNumber").value = bookingNumber;
}
	// Call the function when the page loads
	window.onload = generateBookingNumber;
</script>
</head>
<body>
<?php if($action == "list" || $action == "edit" ){  ?>
<a  href="javascript:formaction1(<?php echo "1";?>)" class="btn btn-primary">Add new </a>&nbsp;<a  href="dashboard.php" class="btn btn-primary">Back </a>
<?php } ?>
<?php if($action == "list") {?>
<table border="1">
  <thead>
    <tr>
      <th style="text-align:center;">No</th>
      <th>Bus Number</th>
      <th>Place</th>
      <th>Day / Night</th>
      <th>Price</th>
      <th>Description</th>
      <th>Tour Date</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php
	$no="0";
	echo $admin_id;
    $select = mysqli_query($con,"SELECT * FROM tourbooking_master ORDER BY tourbooking_id ASC");
	while($row=mysqli_fetch_array($select))
	{ ?>
    <tr>
      <td><?php echo $no=$no+1; ?></td>
      <td><?php echo getbusnumberfrombusid($row['bus_id']); ?></td>
      <td><?php echo $row['tourbooking_place']; ?></td>
      <td><?php echo $row['tourbooking_daynight']; ?></td>
      <td><?php echo $row['tourbooking_price']; ?></td>
      <td><?php echo $row['tourbooking_description']; ?></td>
      <td><?php echo $row['tourbooking_date']; ?></td>
      <td><a href="javascript:formaction(<?php echo "2" ?>,<?php echo $row['tourbooking_id']; ?>)">Update</a> <a href="javascript:if(confirmDelete())formaction(<?php echo "3"; ?>,<?php echo $row['tourbooking_id']; ?>)">Delete</a></td>
    </tr>
    <?php }?>
  </tbody>
</table>
<?php }if($action == "edit") {?>
<?php 
    $select=mysqli_query($con,"SELECT * FROM tour_master where tour_id='$tour_id'");
    while($row=mysqli_fetch_array($select))
    {
		$bus_id = $row['bus_id'];
    ?>
<form method="post">
  <div>
    <h1>Registration Form</h1>
    <input type="text" id="bookingNumber" name="tourbooking_pnrnumber" hidden>
    <label><b>Full Name</b></label>
    <input type="text" name="tourbooking_name" required>
    <br />
    <label><b>Contact Number</b></label>
    <input type="text" name="tourbooking_number" required>
    <br />
    <label><b>Email</b></label>
    <input type="text" name="tourbooking_email" required>
    <br />
    <label><b>Address</b></label>
    <input type="text" name="tourbooking_address" required>
    <br />
    <label><b>Date</b></label>
    <input type="text" name="tourbooking_date" value="<?php echo $row["tour_date"]; ?>"  readonly>
    <br />
    <label><b>Tour Place</b></label>
    <input type="text"name="tourbooking_place" value="<?php echo $row["tour_place"]; ?>" readonly>
    <br />
    <label><b>Days</b></label>
    <input type="text" name="tourbooking_daynight" value="<?php echo $row["tour_daynight"]; ?>" readonly>
    <br />
    <label><b>Price</b></label>
    <input type="text" name="tourbooking_price" value="<?php echo $row["tour_price"]; ?>" readonly>
    <br />
    <label><b>Details</b></label>
    <input type="text" name="tourbooking_description" value="<?php echo $row["tour_description"]; ?>" readonly>
    <br />
    <input type="text" name="tourbooking_status" value="Pandding" hidden>
    <label><b>Bus Number</b></label>
    <select type="text" name="bus_id" style="margin-right: 73px;">
      <option value="<?php echo $row["bus_id"]; ?>"><?php echo getbusnumberfrombusid($row['bus_id']); ?></option>
    </select>
    <br />
    <label><b>Select Seat</b></label>
    <table width="200" border="1" id="seatForm">
      <tr>
        <td><input type="checkbox" id="option1" name="options[]" value="13">
          13</td>
        <td><input type="checkbox" id="option2" name="options[]" value="11">
          11</td>
        <td><input type="checkbox" id="option3" name="options[]" value="9">
          9</td>
        <td><input type="checkbox" id="option4" name="options[]" value="7">
          7</td>
        <td><input type="checkbox" id="option5" name="options[]" value="5">
          5</td>
        <td><input type="checkbox" id="option6" name="options[]" value="3">
          3</td>
        <td><input type="checkbox" id="option7" name="options[]" value="1">
          1</td>
        <td rowspan="2">Entry</td>
      </tr>
      <tr>
        <td><input type="checkbox" id="option8" name="options[]" value="14">
          14</td>
        <td><input type="checkbox" id="option9" name="options[]" value="12">
          12</td>
        <td><input type="checkbox" id="option10" name="options[]" value="10">
          10</td>
        <td><input type="checkbox" id="option11" name="options[]" value="8">
          8</td>
        <td><input type="checkbox" id="option12" name="options[]" value="6">
          6</td>
        <td><input type="checkbox" id="option13" name="options[]" value="4">
          4</td>
        <td><input type="checkbox" id="option14" name="options[]" value="2">
          2</td>
      </tr>
      <tr>
        <td colspan="8">&nbsp;</td>
      </tr>
      <tr>
        <td><input type="checkbox" id="option15" name="options[]" value="15">
          15</td>
        <td><input type="checkbox" id="option16" name="options[]" value="17">
          17</td>
        <td><input type="checkbox" id="option17" name="options[]" value="19">
          19</td>
        <td><input type="checkbox" id="option18" name="options[]" value="21">
          21</td>
        <td><input type="checkbox" id="option19" name="options[]" value="23">
          23</td>
        <td><input type="checkbox" id="option20" name="options[]" value="25">
          25</td>
        <td><input type="checkbox" id="option21" name="options[]" value="27">
          27</td>
        <td rowspan="2">Driver</td>
      </tr>
      <tr>
        <td><input type="checkbox" id="option22" name="options[]" value="16">
          16</td>
        <td><input type="checkbox" id="option23" name="options[]" value="18">
          18</td>
        <td><input type="checkbox" id="option24" name="options[]" value="20">
          20</td>
        <td><input type="checkbox" id="option25" name="options[]" value="22">
          22</td>
        <td><input type="checkbox" id="option26" name="options[]" value="24">
          24</td>
        <td><input type="checkbox" id="option27" name="options[]" value="26">
          26</td>
        <td><input type="checkbox" id="option28" name="options[]" value="28">
          28</td>
      </tr>
    </table>
    <br />
    <input type="submit" name="submit" value="Submit">
    <a href="index.php" class="btn btn-primary">cancel</a> </div>
</form>
<?php
if (isset($_POST['submit']))
	{
		$tour_id = $_SESSION['tour_id'];
		$bus_id = $_POST['bus_id'];
		$tourbooking_pnrnumber = $_POST['tourbooking_pnrnumber'];
		$tourbooking_name = $_POST['tourbooking_name'];
		$tourbooking_number = $_POST['tourbooking_number'];
		$tourbooking_email = $_POST['tourbooking_email'];
		$tourbooking_address = $_POST['tourbooking_address'];
		$tourbooking_date = $_POST['tourbooking_date'];
		$tourbooking_place = $_POST['tourbooking_place'];
		$tourbooking_daynight = $_POST['tourbooking_daynight'];
		$tourbooking_price = $_POST['tourbooking_price'];
		$tourbooking_description = $_POST['tourbooking_description'];
		$tourbooking_status = $_POST['tourbooking_status'];
		$admin_id = $_SESSION['admin_id'];
		$current_date = date("Y-m-d H:i:s");
	
		$selectedOptions = isset($_POST['options']) ? $_POST['options'] : array();
		
		// Sanitize and prepare data for SQL insertion
		$selectedOptions = array_map(function($option) use ($con)
		{
			return $con->real_escape_string($option);
		}, $selectedOptions);
		
		// Check if selected seats are already booked
		foreach ($selectedOptions as $busseats_number)
		{
			$checkSeatQuery = "SELECT * FROM busseats_master WHERE tourbooking_id = '$tourbooking_id' AND busseats_number = '$busseats_number'";
			$result = mysqli_query($con, $checkSeatQuery);
		
			if (mysqli_num_rows($result) > 0)
			{
				echo "<script>alert('Seat $busseats_number is already booked. Please choose another seat.');</script>";
				exit;
			}
		}
	
		foreach ($selectedOptions as $busseats_number)
		{
			$select1 = "INSERT INTO busseats_master (tourbooking_id, tour_id, busseats_number, admin_id, busseats_datetime) VALUES ('$tourbooking_id', '$tour_id', '$busseats_number', '$admin_id', '$current_date')";
			mysqli_query($con, $select1);
			$busseats_id = mysqli_insert_id($con);  
    	}
		
			$sql = "INSERT INTO tourbooking_master(tour_id, bus_id, tourbooking_pnrnumber, tourbooking_name, tourbooking_number, tourbooking_email, tourbooking_address,  tourbooking_date, tourbooking_place, tourbooking_daynight, tourbooking_price, tourbooking_description, tourbooking_status, admin_id, tourbooking_datetime) VALUES  ('$tour_id', '$bus_id', '$tourbooking_pnrnumber', '$tourbooking_name', '$tourbooking_number', '$tourbooking_email', '$tourbooking_address', '$tourbooking_date', '$tourbooking_place', '$tourbooking_daynight', '$tourbooking_price', '$tourbooking_description', '$tourbooking_status', '$admin_id', '$current_date')";
			mysqli_query($con, $sql);
			$tourbooking_id = mysqli_insert_id($con);  

		echo "<script type='text/javascript'>";
		echo "window.location='tour-booking.php?action=payment'";
		echo "</script>";
}
?>
<?php }?>
<?php } if($action == "payment") {?>
<?php 
    $select=mysqli_query($con,"SELECT * FROM tourbooking_master where admin_id = '$admin_id'");
    while($row=mysqli_fetch_array($select))
    {
    ?>
<form method="post">
  <label>Name</label>
  <input type="text" name="payment_card" value="<?php echo getloginusernamefromadminid($row['admin_id']); ?>"readonly>
  <br />
  <label>PNR</label>
  <input type="text" name="payment_edate" value="<?php echo $row['tourbooking_pnrnumber']; ?>"readonly>
  <br />
  <label>Price</label>
  <input type="text" name="payment_cvv" value="<?php echo $row['tourbooking_price']; ?>"readonly>
  <br />
  <label>Travelling Date</label>
  <input type="text" name="payment_name" value="<?php echo $row['tourbooking_date']; ?>" readonly>
  <br />
  <a href="javascript:formaction(<?php echo "7" ?>,<?php echo $row['tourbooking_id']; ?>)">Pay Now</a>
  <a href="index.php" class="btn btn-primary">cancel</a>
</form>
<?php }?>
<?php } if($action == "cbooking") { ?>
<?php 
    $select = mysqli_query($con, "SELECT * FROM tourbooking_master WHERE admin_id='$admin_id'");
	while ($row = mysqli_fetch_array($select)) {
    $tourbooking_status = $row['tourbooking_status'];

    $sql = "UPDATE tourbooking_master SET tourbooking_status = 'Canceled' WHERE admin_id='$admin_id'";
    mysqli_query($con, $sql);
	
	$sql1 = "delete from busseats_master where admin_id  = '$admin_id'";
    mysqli_query($con, $sql1);

    echo "<script type='text/javascript'>";
    echo "window.location='dashboard.php'";
    echo "</script>";
 }?>
<?php } if($action == "delete")
{ 
	$delete = mysqli_query($con,"delete from tourbooking_master where tourbooking_id  = '$tourbooking_id'");
	
	echo "<script type='text/javascript'>";
	echo "window.location='tour-booking.php?action=list'";
	echo "</script>";
}
?>
<?php if($action != "list") {?>
<?php } 
if($action == 'set') 
{	
	$act = $_REQUEST['act'];
	$actionvalue = "";
	
	$tour_id = $_REQUEST['tour'];
	if($tour_id != NULL){ $_SESSION['tour_id'] = $tour_id; }
	
	$tourbooking_id = $_REQUEST['tour'];
	if($tourbooking_id != NULL){ $_SESSION['tourbooking_id'] = $tourbooking_id; }
	
	if($act == "1"){ $actionvalue = "add"; }
	if($act == "2"){ $actionvalue = "edit"; }
	if($act == "3"){ $actionvalue = "delete"; }
	if($act == "4"){ $actionvalue = "view"; }
	if($act == "5"){ $actionvalue = "list"; }
	if($act == "6"){ $actionvalue = "cbooking"; }
	if($act == "7"){ $actionvalue = "payment"; }
	
	if($act == "1")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='tour-booking.php?action=add'";
		echo "</script>";
	}
	if($act == "2")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='tour-booking.php?action=edit'";
		echo "</script>";
	}
	if($act == "3")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='tour-booking.php?action=delete'";
		echo "</script>";
	}
	if($act == "5")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='tour-booking.php?action=list'";
		echo "</script>";
	}
	if($act == "6")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='tour-booking.php?action=cbooking'";
		echo "</script>";
	}
	if($act == "7")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='payment.php?action=payment'";
		echo "</script>";
	}
}
?>
<script>
	$(document).ready(function() {
		$.ajax({
			url: 'getbookedseats.php',
			method: 'GET',
			dataType: 'json',
			success: function(response) {
				// Disable checkboxes for booked seats
				var bookedSeats = response.bookedSeats;

				bookedSeats.forEach(function(seatNumber) {
					$('input[name="options[]"][value="' + seatNumber + '"]').prop('disabled', true);
				});
			},
			error: function(error) {
				console.error('Error fetching booked seats:', error);
			}
		});
	});
</script>
</body>
</html>