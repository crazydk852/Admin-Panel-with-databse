<?php
include('config.php');
include('sismaster.php');
$action = $_REQUEST['action'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript">
function formaction(ID,ID1)
{
	window.location = "tour.php?action=set&act="+ ID + "&tour="+ ID1;
}
function formaction1(ID)
{
	window.location = "tour.php?action=set&act="+ ID;
}
function confirmDelete()
{
    return confirm("Are you sure you want to delete this record?");
}
</script>
</head>
<body>
<?php if($action == "list" || $action == "edit" ){  ?>
<a  href="javascript:formaction1(<?php echo "1";?>)" class="btn btn-primary">Add new </a>&nbsp;<a  href="dashboard.php" class="btn btn-primary">Back </a>
<?php } ?>
<?php if($action == "add") {?>
<form method="post">
  <div>
    <h1>Add Tour Details</h1>
    <br />
    <label><b>Date</b></label>
    <input type="date" name="tour_date">
    <br />
    <label><b>From</b></label>
    <input type="text" name="tour_from">
    <br />
    <label><b>To</b></label>
    <input type="text" name="tour_to">
    <br />
    <label><b>Day / Night</b></label>
    <input type="text" name="tour_daynight">
    <br />
    <label><b>Price</b></label>
    <input type="text" name="tour_price">
    <br />
    <label><b>Description</b></label>
    <textarea type="text" name="tour_description"></textarea>
    <br />
    <label><b>Bus Number</b></label>
    <select type="text" name="bus_id" style="margin-right: 73px;">
      <option value="">--- Select Bus ---</option>
    <?php
	$no="0";
    $select = mysqli_query($con,"SELECT * FROM bus_master ORDER BY bus_id ASC");
	while($row=mysqli_fetch_array($select))
	{ ?>
      <option value="<?php echo $row['bus_id']; ?>"><?php echo $row['bus_number']; ?></option>
    <?php } ?>
    </select>
    <br />
    <input type="submit" name="submit" value="Submit">
    <a href="dashboard.php" class="btn btn-primary">Back</a>
  </div>
</form>
<?php
if (isset($_POST['submit'])) {
    $bus_id = $_POST['bus_id'];
    $tour_date = $_POST['tour_date'];
    $tour_from = $_POST['tour_from'];
    $tour_to = $_POST['tour_to'];
    $tour_daynight = $_POST['tour_daynight'];
    $tour_price = $_POST['tour_price'];
    $tour_description = $_POST['tour_description'];
	
    $current_date = date("Y-m-d H:i:s");

        $sql = "INSERT INTO tour_master(bus_id, tour_date, tour_from, tour_to, tour_daynight, tour_price, tour_description, tour_datetime) VALUES  ('$bus_id', '$tour_date', '$tour_from', '$tour_to', '$tour_daynight', '$tour_price', '$tour_description', '$current_date')";
       
        mysqli_query($con, $sql);
		$tour_id = mysqli_insert_id($con);
		
		echo "<script type='text/javascript'>";
		echo "window.location='tour.php?action=list'";
		echo "</script>";
}
?>
<?php }if($action == "list") {?>
<table border="1">
  <thead>
    <tr>
      <th style="text-align:center;">No</th>
      <th>Bus Number</th>
      <th>From</th>
      <th>To</th>
      <th>Day / Night</th>
      <th>Price</th>
      <th>Description</th>
      <th>Tour Date</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php
	$no="0";
    $select = mysqli_query($con,"SELECT * FROM tour_master ORDER BY tour_id ASC");
	while($row=mysqli_fetch_array($select))
	{ ?>
    <tr>
      <td><?php echo $no=$no+1; ?></td>
      <td><?php echo getbusnumberfrombusid($row['bus_id']); ?></td>
      <td><?php echo $row['tour_from']; ?></td>
      <td><?php echo $row['tour_to']; ?></td>
      <td><?php echo $row['tour_daynight']; ?></td>
      <td><?php echo $row['tour_price']; ?></td>
      <td><?php echo $row['tour_description']; ?></td>
      <td><?php echo $row['tour_date']; ?></td>
      <td><a href="javascript:formaction(<?php echo "2" ?>,<?php echo $row['tour_id']; ?>)">Update</a> <a href="javascript:if(confirmDelete())formaction(<?php echo "3"; ?>,<?php echo $row['tour_id']; ?>)">Delete</a></td>
    </tr>
    <?php }?>
  </tbody>
</table>
<?php }if($action == "edit") {?>
<?php 
    $select=mysqli_query($con,"SELECT * FROM tour_master where tour_id='$tour_id'");
    while($row=mysqli_fetch_array($select))
    {
    ?>
<form method="post">
  <div>
    <h1>Registration Form</h1>
    <label><b>Name</b></label>
    <input type="text" name="tour_date" value="<?php echo $row["tour_date"]; ?>">
    <br />
    <label><b>From</b></label>
    <input type="text"name="tour_from" value="<?php echo $row["tour_from"]; ?>">
    <br />
    <label><b>To</b></label>
    <input type="text"name="tour_to" value="<?php echo $row["tour_to"]; ?>">
    <br />
    <label><b>Days / Night</b></label>
    <input type="text" name="tour_daynight" value="<?php echo $row["tour_daynight"]; ?>">
    <br />
    <label><b>Price</b></label>
    <input type="text" name="tour_price" value="<?php echo $row["tour_price"]; ?>">
    <br />
    <label><b>Description</b></label>
    <input type="text" name="tour_description" value="<?php echo $row["tour_description"]; ?>">
    <br />
    <label><b>Bus Number</b></label>
    <select type="text" name="bus_id" style="margin-right: 73px;">
    <option value="<?php echo $row["bus_id"]; ?>"><?php echo getbusnumberfrombusid($row['bus_id']); ?></option>
    <?php
	$no="0";
    $select1 = mysqli_query($con,"SELECT * FROM bus_master ORDER BY bus_id ASC");
	while($row1=mysqli_fetch_array($select1))
	{ ?>
      <option value="<?php echo $row1['bus_id']; ?>"><?php echo $row1['bus_number']; ?></option>
    <?php } ?>
    </select>
    <br />
    <input type="submit" name="submit" value="Submit">
    <a href="tour.php?action=list" class="btn btn-primary">Back</a> </div>
</form>
<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") {

   	$bus_id = $_POST['bus_id'];
	$tour_date = $_POST['tour_date'];
    $tour_from = $_POST['tour_from'];
    $tour_to = $_POST['tour_to'];
    $tour_daynight = $_POST['tour_daynight'];
    $tour_price = $_POST['tour_price'];
    $tour_description = $_POST['tour_description'];
	
   $sql = "UPDATE tour_master SET bus_id='$bus_id', tour_date='$tour_date', tour_from='$tour_from', tour_to='$tour_to', tour_daynight='$tour_daynight', tour_price='$tour_price', tour_description='$tour_description', tour_datetime='$current_date' WHERE tour_id='$tour_id'";
	mysqli_query($con,$sql);
	
	echo "<script type='text/javascript'>";
	echo "window.location='tour.php?action=list'";
	echo "</script>";
}
?>
<?php }?>
<?php } 
if($action == "delete")
{ 
	$delete = mysqli_query($con,"delete from tour_master where tour_id  = '$tour_id'");
	
	echo "<script type='text/javascript'>";
	echo "window.location='tour.php?action=list'";
	echo "</script>";
}
?>
<?php if($action != "list") {?>
<?php } 
if($action == 'set') 
{	
	$act = $_REQUEST['act'];
	$actionvalue = "";
	
	$tour_id = $_REQUEST['tour'];
	if($tour_id != NULL){ $_SESSION['tour_id'] = $tour_id; }
	
	if($act == "1"){ $actionvalue = "add"; }
	if($act == "2"){ $actionvalue = "edit"; }
	if($act == "3"){ $actionvalue = "delete"; }
	if($act == "4"){ $actionvalue = "view"; }
	if($act == "5"){ $actionvalue = "list"; }
	
	if($act == "1")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='tour.php?action=add'";
		echo "</script>";
	}
	if($act == "2")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='tour.php?action=edit'";
		echo "</script>";
	}
	if($act == "3")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='tour.php?action=delete'";
		echo "</script>";
	}
	if($act == "5")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='tour.php?action=list'";
		echo "</script>";
	}
}
?>
</body>
</html>