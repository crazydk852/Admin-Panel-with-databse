<?php
include_once("config.php");
include('sismaster.php');
$action = $_REQUEST['action'];
$module = 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>BCORE Admin Dashboard Template | Dashboard</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport" />
<meta content="" name="description" />
<meta content="" name="author" />
<?php include('topheader.php'); ?>
<script type="text/javascript">
function formaction(ID,ID1)
{
	window.location = "admin.php?action=set&act="+ ID + "&admin="+ ID1;
}
function formaction1(ID)
{
	window.location = "admin.php?action=set&act="+ ID;
}
function confirmDelete()
{
    return confirm("Are you sure you want to delete this record?");
}
</script>
</head>
<body class="padTop53 " >
<div id="wrap" >
  <?php include('navbar.php'); ?>
  <?php include('sidebar.php'); ?>
  <div id="content">
    <div class="inner">
      <div class="row">
        <div class="col-lg-12">
          <div class="box">
            <?php if($action == "add") {?>
            <header>
              <div class="icons"><i class="icon-th-large"></i></div>
              <h5>Add <?php echo $module; ?></h5>
              <div class="toolbar">
                <a href="admin.php?action=list" class="btn btn-default btn-sm"><i class="icon-reply"></i> Back</a>
              </div>
            </header>
            <div id="collapseOne" class="accordion-body collapse in body">
              <form method="post" class="form-horizontal" id="block-validate">
                <div class="form-group">
                  <label class="control-label col-lg-4">Full Name</label>
                  <div class="col-lg-4">
                    <input type="text" name="admin_fullname" class="form-control" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">E-mail</label>
                  <div class="col-lg-4">
                    <input type="email" name="admin_email" class="form-control" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Phone No.</label>
                  <div class="col-lg-4">
                    <input type="text" name="admin_phone" class="form-control" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Role</label>
                  <div class="col-lg-4">
                    <select name="admin_role" class="form-control">
                      <option value="admin">Admin</option>
                      <option value="manager">Manager</option>
                      <option value="customer">Customer</option>
                    </select>
                  </div>
                </div>
                <div class="form-actions no-margin-bottom" style="text-align:center;">
                  <input type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg " />
                </div>
              </form>
            </div>
            <?php
			if (isset($_POST['submit']))
			{
				$admin_fullname = $_POST['admin_fullname'];
				$admin_email = $_POST['admin_email'];
				$admin_phone = $_POST['admin_phone'];
				$admin_role = $_POST['admin_role'];
			
				$current_date = date("Y-m-d H:i:s");
			
				$select = mysqli_query($con, "SELECT * FROM admin_master WHERE admin_email = '$admin_email'");
				$row = mysqli_fetch_assoc($select);
			
				if ($row) {
					echo "<script>
							alert('This Email Id is already registered!');
							window.location.href = 'addadmin.php';
						  </script>";
					exit();
				}
				else
				{
					$select = "INSERT INTO admin_master(admin_fullname, admin_email, admin_phone, admin_role, admin_datetime) VALUES  ('$admin_fullname','$admin_email','$admin_phone','$admin_role','$current_date')";
					mysqli_query($con,$select);
					
					echo "<script type='text/javascript'>";
					echo "window.location='admin.php?action=list'";
					echo "</script>";
				}
			}
			?>
            <?php } if($action == "list") {?>
            <div class="panel panel-default">
              <div class="panel-heading"> <?php echo $module; ?>s Details </div>
              <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-striped table-bordered table-hover" id="dataTables">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile No</th>
                        <th>Role</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                    $no="0";
                    $select = mysqli_query($con,"SELECT * FROM admin_master ORDER BY admin_id = '$admin_id' ASC");
                    while($row=mysqli_fetch_array($select))
                    { ?>
                      <tr>
                        <td><?php echo $no=$no+1; ?></td>
                        <td><?php echo $row['admin_fullname']; ?></td>
                        <td><?php echo $row['admin_email']; ?></td>
                        <td><?php echo $row['admin_phone']; ?></td>
                        <td><?php echo $row['admin_role']; ?></td>
                        <td><a href="javascript:formaction(<?php echo "2" ?>,<?php echo $row['admin_id']; ?>)" class="btn btn-primary btn-xs"><i class="icon-pencil icon-white"></i> Edit</a> <a href="javascript:formaction(<?php echo "3" ?>,<?php echo $row['admin_id']; ?>)" class="btn btn-danger btn-xs"><i class="icon-remove icon-white"></i> Delete</a></td>
                      </tr>
                      <?php }?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <?php } if($action == "edit") {?>
            <header>
              <div class="icons"><i class="icon-th-large"></i></div>
              <h5>Edit <?php echo $module; ?></h5>
              <div class="toolbar">
                <a href="admin.php?action=list" class="btn btn-default btn-sm"><i class="icon-reply"></i> Back</a>
              </div>
            </header>
            <div id="collapseOne" class="accordion-body collapse in body">
              <?php 
            $select=mysqli_query($con,"SELECT * FROM  admin_master where admin_id='$admin_id'");
            while($row=mysqli_fetch_array($select))
            {
            ?>
              <form method="post" class="form-horizontal" id="block-validate">
                <div class="form-group">
                  <label class="control-label col-lg-4">Full Name</label>
                  <div class="col-lg-4">
                    <input type="text" name="admin_fullname" class="form-control" value="<?php echo $row["admin_fullname"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">E-mail</label>
                  <div class="col-lg-4">
                    <input type="email" name="admin_email" class="form-control" value="<?php echo $row["admin_email"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Phone No.</label>
                  <div class="col-lg-4">
                    <input type="text" name="admin_phone" class="form-control" value="<?php echo $row["admin_phone"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Role</label>
                  <div class="col-lg-4">
                    <select name="admin_role" class="form-control">
                      <option value="<?php echo $row["admin_role"]; ?>" selected><?php echo $row["admin_role"]; ?></option>
                      <option value="admin">Admin</option>
                      <option value="manager">Manager</option>
                      <option value="customer">Customer</option>
                    </select>
                  </div>
                </div>
                <div class="form-actions no-margin-bottom" style="text-align:center;">
                  <input type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg " />
                </div>
              </form>
            </div>
            <?php
			if ($_SERVER["REQUEST_METHOD"] == "POST")
			{
				$admin_fullname= $_POST["admin_fullname"];
				$admin_email= $_POST["admin_email"];
				$admin_phone= $_POST["admin_phone"];
				$admin_role= $_POST["admin_role"];
			   
			   $sql = "UPDATE admin_master SET admin_fullname='$admin_fullname', admin_email='$admin_email', admin_phone='$admin_phone', admin_role='$admin_role' WHERE admin_id='$admin_id'";
				mysqli_query($con,$sql);
	
				echo "<script type='text/javascript'>";
				echo "window.location='admin.php?action=list'";
				echo "</script>";
			}
			?>
            <?php } ?>
            <?php } 
			if($action == "delete")
			{ 
				$delete = mysqli_query($con,"delete from admin_master where admin_id  = '$admin_id'");
				
				echo "<script type='text/javascript'>";
				echo "window.location='admin.php?action=list'";
				echo "</script>";
			}
			?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php if($action != "list") {?>
<?php } 
if($action == 'set') 
{	
	$act = $_REQUEST['act'];
	$actionvalue = "";
	
	$admin_id = $_REQUEST['admin'];
	if($admin_id != NULL){ $_SESSION['admin_id'] = $admin_id; }
	
	if($act == "1"){ $actionvalue = "add"; }
	if($act == "2"){ $actionvalue = "edit"; }
	if($act == "3"){ $actionvalue = "delete"; }
	if($act == "4"){ $actionvalue = "view"; }
	if($act == "5"){ $actionvalue = "list"; }
	
	if($act == "1")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='admin.php?action=add'";
		echo "</script>";
	}
	if($act == "2")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='admin.php?action=edit'";
		echo "</script>";
	}
	if($act == "3")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='admin.php?action=delete'";
		echo "</script>";
	}
	if($act == "5")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='admin.php?action=list'";
		echo "</script>";
	}
}
?>
<?php include('footer.php'); ?>
<?php include('footerscript.php'); ?>
<script>
$(document).ready(function () {
$('#dataTables').dataTable();
});
</script> 
</body>
</html>