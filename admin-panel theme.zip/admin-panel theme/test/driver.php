<?php
include_once("config.php");
include('sismaster.php');
$action = $_REQUEST['action'];
$module = 'Driver';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>BCORE Admin Dashboard Template | Dashboard</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport" />
<meta content="" name="description" />
<meta content="" name="author" />
<?php include('topheader.php'); ?>
<script type="text/javascript">
function formaction(ID,ID1)
{
	window.location = "driver.php?action=set&act="+ ID + "&view="+ ID1;
}
function formaction1(ID)
{
	window.location = "driver.php?action=set&act="+ ID;
}
function confirmDelete()
{
    return confirm("Are you sure you want to delete this record?");
}
</script>
</head>
<body class="padTop53">
<div id="wrap" >
  <?php include('navbar.php'); ?>
  <?php include('sidebar.php'); ?>
  <div id="content">
    <div class="inner">
      <div class="row">
        <div class="col-lg-12">
          <div class="box">
            <?php if($action == "add") {?>
            <header>
              <div class="icons"><i class="icon-th-large"></i></div>
              <h5>Add <?php echo $module; ?></h5>
              <div class="toolbar"> <a href="driver.php?action=list" class="btn btn-default btn-sm"><i class="icon-reply"></i> Back</a> </div>
            </header>
            <div id="collapseOne" class="accordion-body collapse in body">
              <form method="post" class="form-horizontal" id="block-validate" enctype="multipart/form-data">
                <div class="form-group">
                  <label class="control-label col-lg-4">Full Name</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_name" class="form-control" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Phone No.</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_phone" class="form-control" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">License No.</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_licenseno" class="form-control" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Vehical No.</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_vehicalno" class="form-control" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Vehical Type</label>
                  <div class="col-lg-4">
                    <select name="diver_vehicaltype" class="form-control">
                      <option value="AC">AC</option>
                      <option value="NON AC">NON AC</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Vehical Mode</label>
                  <div class="col-lg-4">
                    <select name="diver_vehicalmode" class="form-control">
                      <option value="Sleeper">Sleeper</option>
                      <option value="Chair Seat">Chair Seat</option>
                      <option value="Volvo">Volvo</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">License & RC</label>
                  <div class="col-lg-2">
                    <div class="fileupload fileupload-new" data-provides="fileupload">
                      <div class="fileupload-preview thumbnail" style="width: 150px; height: 100px;"></div>
                      <div> <span class="btn btn-file btn-success"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span>
                        <input type="file" name="diver_license" accept="image/*" />
                        </span> <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload">Remove</a> </div>
                    </div>
                  </div>
                  <div class="col-lg-2">
                    <div class="fileupload fileupload-new" data-provides="fileupload">
                      <div class="fileupload-preview thumbnail" style="width: 150px; height: 100px;"></div>
                      <div> <span class="btn btn-file btn-success"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span>
                        <input type="file" name="diver_rc" accept="image/*" />
                        </span> <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload">Remove</a> </div>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Bus Photo</label>
                  <div class="col-lg-4">
                    <div class="fileupload fileupload-new" data-provides="fileupload">
                      <div class="fileupload-preview thumbnail" style="width: 100%; height: 100px;"></div>
                      <div> <span class="btn btn-file btn-success"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span>
                        <input type="file" name="diver_bus" accept="image/*" />
                        </span> <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload">Remove</a> </div>
                    </div>
                  </div>
                </div>
                <div class="form-actions no-margin-bottom" style="text-align:center;">
                  <input type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg " />
                </div>
              </form>
            </div>
            <?php
			if (isset($_POST['submit']))
			{
				$diver_name = $_POST['diver_name'];
				$diver_phone = $_POST['diver_phone'];
				$diver_licenseno = $_POST['diver_licenseno'];
				$diver_vehicalno = $_POST['diver_vehicalno'];
				$diver_vehicaltype = $_POST['diver_vehicaltype'];
				$diver_vehicalmode = $_POST['diver_vehicalmode'];
				
				$diverlicense = uploadFile("diver_license");
				$diverrc = uploadFile("diver_rc");
				$diverbus = uploadFile("diver_bus");
			
				$current_date = date("Y-m-d H:i:s");
				
				$select = "INSERT INTO diver_master(diver_name, diver_phone, diver_licenseno, diver_vehicalno, diver_vehicaltype, diver_vehicalmode, diver_license, diver_rc, diver_bus, admin_id, diver_datetime) VALUES  ('$diver_name', '$diver_phone', '$diver_licenseno', '$diver_vehicalno', '$diver_vehicaltype', '$diver_vehicalmode', '$diverlicense', '$diverrc', '$diverbus', '$admin_id', '$current_date')";
				mysqli_query($con,$select);
				
				echo "<script type='text/javascript'>";
				echo "window.location='driver.php?action=list'";
				echo "</script>";
			}
			?>
            <?php } if($action == "list") {?>
            <header>
              <div class="icons"><i class="icon-th-large"></i></div>
              <h5> <?php echo $module; ?>s Details </h5>
              <div class="toolbar"> <a href="driver.php?action=add" class="btn btn-default btn-sm"><i class="icon-reply"></i> Add New</a> </div>
            </header>
            <div class="panel panel-default">
              <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-striped table-bordered table-hover" id="dataTables">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Mobile No</th>
                        <th>License No</th>
                        <th>Vehical No</th>
                        <th>Vehical Type</th>
                        <th>Vehical Mode</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                    $no="0";
                    $select = mysqli_query($con,"SELECT * FROM diver_master ORDER BY diver_id ASC");
                    while($row=mysqli_fetch_array($select))
                    { ?>
                      <tr>
                        <td><?php echo $no=$no+1; ?></td>
                        <td><?php echo $row['diver_name']; ?></td>
                        <td><?php echo $row['diver_phone']; ?></td>
                        <td><?php echo $row['diver_licenseno']; ?></td>
                        <td><?php echo $row['diver_vehicalno']; ?></td>
                        <td><?php echo $row['diver_vehicaltype']; ?></td>
                        <td><?php echo $row['diver_vehicalmode']; ?></td>
                        <td><a href="javascript:formaction(<?php echo "4" ?>,<?php echo $row['diver_id']; ?>)" class="btn btn-xs"><i class="icon-eye-open"></i> View</a> <a href="javascript:formaction(<?php echo "2" ?>,<?php echo $row['diver_id']; ?>)" class="btn btn-primary btn-xs"><i class="icon-pencil icon-white"></i> Edit</a> <a href="javascript:formaction(<?php echo "3" ?>,<?php echo $row['diver_id']; ?>)" class="btn btn-danger btn-xs"><i class="icon-remove icon-white"></i> Delete</a></td>
                      </tr>
                      <?php }?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <?php } if($action == "view") {?>
            <header>
              <div class="icons"><i class="icon-th-large"></i></div>
              <h5>Edit <?php echo $module; ?></h5>
              <div class="toolbar"> <a href="driver.php?action=list" class="btn btn-default btn-sm"><i class="icon-reply"></i> Back</a> </div>
            </header>
            <div id="collapseOne" class="accordion-body collapse in body">
              <?php 
            $select=mysqli_query($con,"SELECT * FROM diver_master where diver_id='$diver_id'");
            while($row=mysqli_fetch_array($select))
            {
            ?>
              <form method="post" class="form-horizontal" id="block-validate" enctype="multipart/form-data">
                <div class="form-group">
                  <label class="control-label col-lg-4">Full Name</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_name" class="form-control" value="<?php echo $row["diver_name"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Phone No.</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_phone" class="form-control" value="<?php echo $row["diver_phone"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">License No.</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_licenseno" class="form-control" value="<?php echo $row["diver_licenseno"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Vehical No.</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_vehicalno" class="form-control" value="<?php echo $row["diver_vehicalno"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Vehical Type</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_vehicalno" class="form-control" value="<?php echo $row["diver_vehicaltype"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Vehical Mode</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_vehicalno" class="form-control" value="<?php echo $row["diver_vehicalmode"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">License & RC</label>
                  <div class="col-lg-2"> <img src="<?php echo $row["diver_license"]; ?>" style="width: 150px; height: 100px;"> </div>
                  <div class="col-lg-2"> <img src="<?php echo $row["diver_rc"]; ?>" style="width: 150px; height: 100px;"> </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Bus Photo</label>
                  <div class="col-lg-4"> <img src="<?php echo $row["diver_bus"]; ?>" style="width: 150px; height: 100px;"> </div>
                </div>
                <div class="form-actions no-margin-bottom" style="text-align:center;"> <a href="javascript:formaction(<?php echo "2" ?>,<?php echo $row['diver_id']; ?>)" class="btn btn-primary btn-lg"><i class="icon-pencil icon-white"></i> Edit</a> </div>
              </form>
            </div>
            <?php }?>
            <?php } if($action == "edit") {?>
            <header>
              <div class="icons"><i class="icon-th-large"></i></div>
              <h5>Edit <?php echo $module; ?></h5>
              <div class="toolbar"> <a href="driver.php?action=list" class="btn btn-default btn-sm"><i class="icon-reply"></i> Back</a> </div>
            </header>
            <div id="collapseOne" class="accordion-body collapse in body">
              <?php 
            $select=mysqli_query($con,"SELECT * FROM diver_master where diver_id='$diver_id'");
            while($row=mysqli_fetch_array($select))
            {
            ?>
              <form method="post" class="form-horizontal" id="block-validate" enctype="multipart/form-data">
                <div class="form-group">
                  <label class="control-label col-lg-4">Full Name</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_name" class="form-control" value="<?php echo $row["diver_name"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Phone No.</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_phone" class="form-control" value="<?php echo $row["diver_phone"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">License No.</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_licenseno" class="form-control" value="<?php echo $row["diver_licenseno"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Vehical No.</label>
                  <div class="col-lg-4">
                    <input type="text" name="diver_vehicalno" class="form-control" value="<?php echo $row["diver_vehicalno"]; ?>" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Vehical Type</label>
                  <div class="col-lg-4">
                    <select name="diver_vehicaltype" class="form-control">
                      <option value="<?php echo $row["diver_vehicaltype"]; ?>"><?php echo $row["diver_vehicaltype"]; ?></option>
                      <option value="AC">AC</option>
                      <option value="NON AC">NON AC</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Vehical Mode</label>
                  <div class="col-lg-4">
                    <select name="diver_vehicalmode" class="form-control">
                      <option value="<?php echo $row["diver_vehicalmode"]; ?>"><?php echo $row["diver_vehicalmode"]; ?></option>
                      <option value="Sleeper">Sleeper</option>
                      <option value="Chair Seat">Chair Seat</option>
                      <option value="Volvo">Volvo</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">License & RC</label>
                  <div class="col-lg-2">
                    <div class="fileupload fileupload-new" data-provides="fileupload">
                      <div class="fileupload-preview thumbnail" style="width: 150px; height: 100px;"><img src="<?php echo $row["diver_license"]; ?>"></div>
                      <div> <span class="btn btn-file btn-success"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span>
                        <input type="file" name="diver_license" accept="image/*" />
                        </span> <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload">Remove</a> </div>
                    </div>
                  </div>
                  <div class="col-lg-2">
                    <div class="fileupload fileupload-new" data-provides="fileupload">
                      <div class="fileupload-preview thumbnail" style="width: 150px; height: 100px;"><img src="<?php echo $row["diver_rc"]; ?>"></div>
                      <div> <span class="btn btn-file btn-success"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span>
                        <input type="file" name="diver_license" accept="image/*" />
                        </span> <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload">Remove</a> </div>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-4">Bus Photo</label>
                  <div class="col-lg-4">
                    <div class="fileupload fileupload-new" data-provides="fileupload">
                      <div class="fileupload-preview thumbnail" style="width: 150px; height: 100px;"><img src="<?php echo $row["diver_bus"]; ?>"></div>
                      <div> <span class="btn btn-file btn-success"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span>
                        <input type="file" name="diver_license" accept="image/*" />
                        </span> <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload">Remove</a> </div>
                    </div>
                  </div>
                </div>
                <div class="form-actions no-margin-bottom" style="text-align:center;">
                  <input type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg " />
                </div>
              </form>
            </div>
            <?php
			if ($_SERVER["REQUEST_METHOD"] == "POST")
			{
				$diver_name = $_POST['diver_name'];
				$diver_phone = $_POST['diver_phone'];
				$diver_licenseno = $_POST['diver_licenseno'];
				$diver_vehicalno = $_POST['diver_vehicalno'];
				$diver_vehicaltype = $_POST['diver_vehicaltype'];
				$diver_vehicalmode = $_POST['diver_vehicalmode'];
				
				$current_date = date("Y-m-d H:i:s");
				
				$upload_error = false;

				$result = mysqli_query($con, "SELECT * FROM diver_master WHERE diver_vehicalno='$diver_vehicalno' AND diver_id != '$diver_id'");
				if (mysqli_fetch_assoc($result))
				{
					$upload_error = true;
				}
			
				if (!$upload_error)
				{
					if (!empty($_FILES['diver_license']['name']))
					{
						$select = mysqli_query($con, "SELECT diver_license FROM diver_master WHERE diver_id = $diver_id");
						$row = mysqli_fetch_assoc($select);
						$diverlicense = $row['diver_license'];
						if ($diverlicense)
						{
							unlink($diverlicense);
						}
						$diver_license = uploadFile("diver_license");
						$update = "UPDATE diver_master SET diver_license='$diver_license' WHERE diver_id='$diver_id'";
						mysqli_query($con,$update);
					}
					if (!empty($_FILES['diver_rc']['name']))
					{
						$select = mysqli_query($con, "SELECT diver_rc FROM diver_master WHERE diver_id = $diver_id");
						$row = mysqli_fetch_assoc($select);
						$diverrc = $row['diver_rc'];
						if ($diverrc)
						{
							unlink($diverrc);
						}
						$diver_rc = uploadFile("diver_rc");
						$update = "UPDATE diver_master SET diver_rc='$diver_rc' WHERE diver_id='$diver_id'";
						mysqli_query($con,$update);
					}
					if (!empty($_FILES['diver_bus']['name']))
					{
						$select = mysqli_query($con, "SELECT diver_bus FROM diver_master WHERE diver_id = $diver_id");
						$row = mysqli_fetch_assoc($select);
						$diverbus = $row['diver_bus'];
						if ($diverbus)
						{
							unlink($diverbus);
						}
						$diver_bus = uploadFile("diver_bus");
						$update = "UPDATE diver_master SET diver_bus='$diver_bus' WHERE diver_id='$diver_id'";
						mysqli_query($con,$update);
					}
			   
			   $sql = "UPDATE diver_master SET diver_name='$diver_name', diver_phone='$diver_phone', diver_licenseno='$diver_licenseno', diver_vehicalno='$diver_vehicalno', diver_vehicaltype='$diver_vehicaltype', diver_vehicalmode='$diver_vehicalmode', admin_id='$admin_id', diver_datetime='$current_date' WHERE diver_id='$diver_id'";
				mysqli_query($con,$sql);
	
				echo "<script type='text/javascript'>";
				echo "window.location='driver.php?action=list'";
				echo "</script>";
			}

			if ($upload_error)
			{
				echo "Error updating record: Product name already exists.";
			}
			}
			?>
            <?php } ?>
            <?php } 
			if($action == "delete")
			{ 
				$delete = mysqli_query($con,"SELECT diver_license, diver_rc, diver_bus FROM diver_master WHERE diver_id = $diver_id");
				while($row=mysqli_fetch_array($delete))
                { 
					// Delete image and PDF files
					unlink($row['diver_license']);
					unlink($row['diver_rc']);
					unlink($row['diver_bus']);
				}
				
				$delete = mysqli_query($con,"delete from diver_master where diver_id  = '$diver_id'");
				
				echo "<script type='text/javascript'>";
				echo "window.location='driver.php?action=list'";
				echo "</script>";
			}
			?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php if($action != "list") {?>
<?php } 
if($action == 'set') 
{	
	$act = $_REQUEST['act'];
	$actionvalue = "";
	
	$diver_id = $_REQUEST['driver'];
	if($diver_id != NULL){ $_SESSION['diver_id'] = $diver_id; }
	
	if($act == "1"){ $actionvalue = "add"; }
	if($act == "2"){ $actionvalue = "edit"; }
	if($act == "3"){ $actionvalue = "delete"; }
	if($act == "4"){ $actionvalue = "view"; }
	if($act == "5"){ $actionvalue = "list"; }
	
	if($act == "1")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='driver.php?action=add'";
		echo "</script>";
	}
	if($act == "2")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='driver.php?action=edit'";
		echo "</script>";
	}
	if($act == "3")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='driver.php?action=delete'";
		echo "</script>";
	}
	if($act == "4")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='driver.php?action=view'";
		echo "</script>";
	}
	if($act == "5")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='driver.php?action=list'";
		echo "</script>";
	}
}
?>
<?php include('footer.php'); ?>
<?php include('footerscript.php'); ?>
<script>
$(document).ready(function () {
$('#dataTables').dataTable();
});
</script>
</body>
</html>