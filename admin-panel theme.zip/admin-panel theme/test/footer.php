<div id="footer">
  <p>&copy;  binarytheme &nbsp;2014 &nbsp;</p>
</div>