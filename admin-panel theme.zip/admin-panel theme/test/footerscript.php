<script src="assets/plugins/jquery-2.0.3.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="assets/plugins/modernizr-2.6.2-respond-1.1.0.min.js"></script>
<script src="assets/plugins/dataTables/jquery.dataTables.js"></script>
<script src="assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script src="assets/plugins/jasny/js/bootstrap-fileupload.js"></script>