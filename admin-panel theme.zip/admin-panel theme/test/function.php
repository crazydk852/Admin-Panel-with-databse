<?php
function getloginusernamefromadminid($admin_id)
{
	global $con;
	$sql=mysqli_query($con,"SELECT * FROM admin_master WHERE admin_id = '$admin_id'");
	while($row=mysqli_fetch_array($sql))
	{
		return $row['admin_fullname'];
	}
}
function getcustomerid($customer_id)
{
	global $con;
	$admin_id = $_SESSION['admin_id'];
	$sql=mysqli_query($con,"SELECT * FROM customer_master WHERE admin_id = '$admin_id'");
	while($row=mysqli_fetch_array($sql))
	{
		return $row['customer_id'];
	}
}
function getbusnumberfrombusid($bus_id)
{
	global $con;
	$sql=mysqli_query($con,"SELECT * FROM bus_master WHERE bus_id = '$bus_id'");
	while($row=mysqli_fetch_array($sql))
	{
		return $row['bus_number'];
	}
}
function getbusseatfromtourbookingid($admin_id)
{
    global $con;
    $sql = mysqli_query($con, "SELECT * FROM busseats_master WHERE admin_id = '$admin_id'");
    $seats = array();
    while ($row = mysqli_fetch_array($sql))
    {
        $seats[] = $row['busseats_number'];
    }
    return implode(', ', $seats);
}
function uploadFile($inputName)
{
	$targetDir = "uploads/";
	$targetFile = $targetDir . basename($_FILES[$inputName]["name"]);
	move_uploaded_file($_FILES[$inputName]["tmp_name"], $targetFile);
	return $targetFile;
}
?>