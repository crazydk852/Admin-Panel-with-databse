﻿<?php
include_once("config.php");
include('sismaster.php');
$action = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>BCORE Admin Dashboard Template | Dashboard</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport" />
<meta content="" name="description" />
<meta content="" name="author" />
<link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="assets/css/main.css" />
<link rel="stylesheet" href="assets/css/theme.css" />
<link rel="stylesheet" href="assets/css/MoneAdmin.css" />
<link rel="stylesheet" href="assets/plugins/Font-Awesome/css/font-awesome.css" />
<link href="assets/css/layout2.css" rel="stylesheet" />
<link href="assets/plugins/flot/examples/examples.css" rel="stylesheet" />
<link rel="stylesheet" href="assets/plugins/timeline/timeline.css" />
<link rel="stylesheet" href="assets/plugins/magic/magic.css" />
<link href="assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<script type="text/javascript">
function formaction(ID,ID1)
{
	window.location = "admin.php?action=set&act="+ ID + "&admin="+ ID1;
}
function formaction2(ID,ID1)
{
	window.location = "payment.php?action=set&act="+ ID + "&tour="+ ID1;
}
function confirmCancel()
{
    return confirm("Are you sure you want to Cancel your booking?");
}
</script>
</head>
<body class="padTop53 " >
<div id="wrap" >
  <?php include('navbar.php'); ?>
  <?php include('sidebar.php'); ?>
  <div id="content">
    <div class="inner" style="min-height: 700px;">
      <div class="row">
        <div class="col-lg-12">
          <h1> Admin Dashboard </h1>
        </div>
      </div>
      <hr />
      <div class="row">
        <div class="col-lg-12">
          <div style="text-align: center;"> <a class="quick-btn" href="#"> <i class="icon-check icon-2x"></i> <span> Products</span> <span class="label label-danger">2</span> </a> <a class="quick-btn" href="#"> <i class="icon-envelope icon-2x"></i> <span>Messages</span> <span class="label label-success">456</span> </a> <a class="quick-btn" href="#"> <i class="icon-signal icon-2x"></i> <span>Profit</span> <span class="label label-warning">+25</span> </a> <a class="quick-btn" href="#"> <i class="icon-external-link icon-2x"></i> <span>value</span> <span class="label btn-metis-2">3.14159265</span> </a> <a class="quick-btn" href="#"> <i class="icon-lemon icon-2x"></i> <span>tasks</span> <span class="label btn-metis-4">107</span> </a> <a class="quick-btn" href="#"> <i class="icon-bolt icon-2x"></i> <span>Tickets</span> <span class="label label-default">20</span> </a> </div>
        </div>
      </div>
      <hr />
      <div class="row">
        <div class="col-lg-12">
        <?php if($_SESSION['admin_role'] == 'admin'){ ?>
          <div class="panel panel-default">
            <div class="panel-heading"> Users Details </div>
            <div class="panel-body">
              <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover" id="dataTables">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile No</th>
                      <th>Role</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $no="0";
                    $select = mysqli_query($con,"SELECT * FROM admin_master ORDER BY admin_id = '$admin_id' ASC");
                    while($row=mysqli_fetch_array($select))
                    { ?>
                    <tr>
                      <td><?php echo $no=$no+1; ?></td>
                      <td><?php echo $row['admin_fullname']; ?></td>
                      <td><?php echo $row['admin_email']; ?></td>
                      <td><?php echo $row['admin_phone']; ?></td>
                      <td><?php echo $row['admin_role']; ?></td>
                      <td><a href="javascript:formaction(<?php echo "2" ?>,<?php echo $row['admin_id']; ?>)" class="btn btn-primary btn-xs"><i class="icon-pencil icon-white"></i> Edit</a> <a href="delete-admin.php?admin_id=<?php echo $row['admin_id']; ?>" class="btn btn-danger btn-xs"><i class="icon-remove icon-white"></i> Delete</a></td>
                    </tr>
                    <?php }?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
         <?php } if($_SESSION['admin_role'] == 'admin' || $_SESSION['admin_role'] == 'manager') { ?>
          <div class="panel panel-default">
            <div class="panel-heading"> Users Details </div>
            <div class="panel-body">
              <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover" id="dataTables1">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile No</th>
                      <th>Address</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
					<?php
                    $no="0";
                    $select = mysqli_query($con,"SELECT * FROM customer_master ORDER BY admin_id = '$admin_id' ASC");
                    while($row=mysqli_fetch_array($select))
                    { ?>
                    <tr>
                      <td><?php echo $no=$no+1; ?></td>
                      <td><?php echo $row['customer_fullname']; ?></td>
                      <td><?php echo $row['customer_email']; ?></td>
                      <td><?php echo $row['customer_phone']; ?></td>
                      <td><?php echo $row['customer_address']; ?></td>
                      <td><a href="editcustomer.php?customer_id=<?php echo $row['customer_id']; ?>" class="btn btn-primary btn-xs"><i class="icon-pencil icon-white"></i> Edit</a> <a href="deletecustomer.php?customer_id=<?php echo $row['customer_id']; ?>" class="btn btn-danger btn-xs"><i class="icon-remove icon-white"></i> Delete</a></td>
                    </tr>
                    <?php }?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
         <?php } ?>
        </div>
      </div>
    </div>
  </div>
  <div id="right">
    <div class="well well-small">
      <ul class="list-unstyled">
        <li>Visitor &nbsp; : <span>23,000</span></li>
        <li>Users &nbsp; : <span>53,000</span></li>
        <li>Registrations &nbsp; : <span>3,000</span></li>
      </ul>
    </div>
    <div class="well well-small">
      <button class="btn btn-block"> Help </button>
      <button class="btn btn-primary btn-block"> Tickets</button>
      <button class="btn btn-info btn-block"> New </button>
      <button class="btn btn-success btn-block"> Users </button>
      <button class="btn btn-danger btn-block"> Profit </button>
      <button class="btn btn-warning btn-block"> Sales </button>
      <button class="btn btn-inverse btn-block"> Stock </button>
    </div>
    <div class="well well-small"> <span>Profit</span><span class="pull-right"><small>20%</small></span>
      <div class="progress mini">
        <div class="progress-bar progress-bar-info" style="width: 20%"></div>
      </div>
      <span>Sales</span><span class="pull-right"><small>40%</small></span>
      <div class="progress mini">
        <div class="progress-bar progress-bar-success" style="width: 40%"></div>
      </div>
      <span>Pending</span><span class="pull-right"><small>60%</small></span>
      <div class="progress mini">
        <div class="progress-bar progress-bar-warning" style="width: 60%"></div>
      </div>
      <span>Summary</span><span class="pull-right"><small>80%</small></span>
      <div class="progress mini">
        <div class="progress-bar progress-bar-danger" style="width: 80%"></div>
      </div>
    </div>
  </div>
</div>
<?php 
if($action == 'set') 
{	
	$act = $_REQUEST['act'];
	$actionvalue = "";
	
	$admin_id = $_REQUEST['admin'];
	if($admin_id != NULL){ $_SESSION['admin_id'] = $admin_id; }
	
	if($act == "2"){ $actionvalue = "edit"; }
	
	if($act == "2")
	{ 
		echo "<script type='text/javascript'>";
		echo "window.location='admin.php?action=edit'";
		echo "</script>";
	}
}
?>
<?php include('footer.php'); ?>
<?php include('footerscript.php'); ?>
<script>
$(document).ready(function () {
$('#dataTables').dataTable();
});
</script>
<script>
$(document).ready(function () {
$('#dataTables1').dataTable();
});
</script>
<script src="assets/plugins/jquery-2.0.3.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="assets/plugins/modernizr-2.6.2-respond-1.1.0.min.js"></script> 
<script src="assets/plugins/flot/jquery.flot.js"></script> 
<script src="assets/plugins/flot/jquery.flot.resize.js"></script> 
<script src="assets/plugins/flot/jquery.flot.time.js"></script> 
<script  src="assets/plugins/flot/jquery.flot.stack.js"></script> 
<script src="assets/js/for_index.js"></script>
<script src="assets/plugins/dataTables/jquery.dataTables.js"></script> 
<script src="assets/plugins/dataTables/dataTables.bootstrap.js"></script>
</body>
</html>
