<div id="left" >
  <div class="media user-media well-small"> <a class="user-link" href="#"> <img class="media-object img-thumbnail user-img" alt="User Picture" src="assets/img/user.gif" /> </a> <br />
    <div class="media-body">
      <h5 class="media-heading"> <?php echo getloginusernamefromadminid($_SESSION['admin_id']); ?></h5>
      <ul class="list-unstyled user-info">
        <li> <a class="btn btn-success btn-xs btn-circle" style="width: 10px;height: 12px;"></a> Online </li>
      </ul>
    </div>
    <br />
  </div>
  <ul id="menu" class="collapse">
    <li class="panel active"> <a href="index.php" > <i class="icon-table"></i> Dashboard </a> </li>
    <li class="panel "> <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#admin-nav"> <i class="icon-tasks"> </i>Admin Management <span class="pull-right"> <i class="icon-angle-left"></i> </span></a>
      <ul class="collapse" id="admin-nav">
        <li class=""><a href="admin.php?action=add"><i class="icon-angle-right"></i> Add New </a></li>
        <li class=""><a href="admin.php?action=list"><i class="icon-angle-right"></i> List </a></li>
      </ul>
    </li>
    <li class="panel "> <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#tour-nav"> <i class="icon-tasks"> </i>Tour Management <span class="pull-right"> <i class="icon-angle-left"></i> </span></a>
      <ul class="collapse" id="tour-nav">
        <li class=""><a href="driver.php?action=list"><i class="icon-angle-right"></i> Driver List </a></li>
        <li class=""><a href="admin.php?action=list"><i class="icon-angle-right"></i> Tour </a></li>
      </ul>
    </li>
  </ul>
</div>
