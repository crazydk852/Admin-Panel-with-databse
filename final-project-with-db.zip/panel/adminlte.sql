-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2024 at 11:26 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adminlte`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_master`
--

CREATE TABLE `admin_master` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(25) NOT NULL,
  `admin_email` varchar(25) NOT NULL,
  `admin_password` varchar(10) NOT NULL,
  `admin_role` varchar(10) NOT NULL,
  `admin_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_master`
--

INSERT INTO `admin_master` (`admin_id`, `admin_name`, `admin_email`, `admin_password`, `admin_role`, `admin_datetime`) VALUES
(1, 'Deepak Patel', 'admin@gmail.com', '123', 'admin', '2024-05-15 10:52:21'),
(2, 'Raju', 'raju@gmail.com', '123', 'manager', '2024-05-15 10:52:35'),
(8, 'Meet Patel', 'meet@gmail.com', '123', 'manager', '2024-05-15 10:52:47'),
(9, 'demo', 'demo@gmail.com', '123', 'manager', '2024-05-15 10:52:50'),
(10, 'jatan', 'jatan@gmail.com', '123', 'manager', '2024-05-27 04:48:49');

-- --------------------------------------------------------

--
-- Table structure for table `category_master`
--

CREATE TABLE `category_master` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(25) NOT NULL,
  `category_rank` int(10) NOT NULL,
  `category_photo` varchar(50) NOT NULL,
  `category_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category_master`
--

INSERT INTO `category_master` (`category_id`, `category_name`, `category_rank`, `category_photo`, `category_datetime`) VALUES
(1, 'category 1', 1, 'uploads/category 1.jpg', '2024-04-24 11:05:32'),
(2, 'category 2', 2, 'uploads/category 2.jpg', '2024-04-24 11:08:55'),
(3, 'category 3', 3, 'uploads/category 3.jpg', '2024-04-24 12:27:37'),
(5, 'category 4', 4, 'uploads/category 4.jpg', '2024-05-13 11:45:37');

-- --------------------------------------------------------

--
-- Table structure for table `chat_master`
--

CREATE TABLE `chat_master` (
  `chat_id` int(11) NOT NULL,
  `sender_id` int(25) NOT NULL,
  `sender_name` varchar(25) NOT NULL,
  `chat_message` text NOT NULL,
  `receiver_id` int(25) NOT NULL,
  `receiver_name` varchar(25) NOT NULL,
  `chat_notification` int(11) NOT NULL,
  `chat_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chat_master`
--

INSERT INTO `chat_master` (`chat_id`, `sender_id`, `sender_name`, `chat_message`, `receiver_id`, `receiver_name`, `chat_notification`, `chat_datetime`) VALUES
(3, 1, 'Deepak Patel', 'Hi', 8, 'Meet Patel', 0, '2024-05-01 04:41:45'),
(4, 8, 'Meet Patel', 'Hello', 1, 'Deepak Patel', 0, '2024-05-01 04:41:49'),
(6, 1, 'Deepak Patel', 'How are you?', 8, 'Meet Patel', 0, '2024-05-01 04:42:16'),
(7, 8, 'Meet Patel', 'Fine. And you?', 1, 'Deepak Patel', 0, '2024-05-01 04:42:25'),
(8, 8, 'Meet Patel', 'fsdsdf', 1, 'Deepak Patel', 0, '2024-05-01 04:50:28'),
(9, 8, 'Meet Patel', 'sdfdsfds', 1, 'Deepak Patel', 0, '2024-05-01 04:50:30'),
(10, 8, 'Meet Patel', 'sdfsdf', 1, 'Deepak Patel', 0, '2024-05-01 04:50:33'),
(11, 8, 'Meet Patel', 'sdfsdf', 1, 'Deepak Patel', 0, '2024-05-01 04:50:37'),
(23, 2, 'Raju', 'hello', 8, 'Meet Patel', 0, '2024-05-02 02:05:14'),
(24, 1, 'Deepak Patel', 'hee', 8, 'Meet Patel', 0, '2024-05-02 02:05:44'),
(25, 1, 'Deepak Patel', 'hii', 8, 'Meet Patel', 0, '2024-05-02 02:08:54'),
(28, 8, 'Meet Patel', 'meet', 1, 'Deepak Patel', 0, '2024-05-02 02:29:51'),
(35, 1, 'Deepak Patel', 'fs', 2, 'Raju', 0, '2024-05-02 02:34:07'),
(36, 1, 'Deepak Patel', 'ds', 2, 'Raju', 0, '2024-05-02 02:34:20'),
(37, 2, 'Raju', 'fdff', 1, 'Deepak Patel', 0, '2024-05-02 02:34:24'),
(38, 2, 'Raju', 'dfd', 1, 'Deepak Patel', 0, '2024-05-02 02:34:27'),
(39, 1, 'Deepak Patel', 'sdfds', 2, 'Raju', 0, '2024-05-02 02:34:30'),
(40, 2, 'Raju', 'ads', 1, 'Deepak Patel', 0, '2024-05-02 02:34:34'),
(41, 1, 'Deepak Patel', 'asdsa', 2, 'Raju', 0, '2024-05-02 02:34:38'),
(42, 2, 'Raju', 'sdfs', 1, 'Deepak Patel', 0, '2024-05-02 02:34:44'),
(45, 1, 'Deepak Patel', 'hi', 2, 'Raju', 1, '2024-05-14 01:54:40'),
(46, 1, 'Deepak Patel', 'adaa', 2, 'Raju', 1, '2024-05-14 01:55:21'),
(47, 1, 'Deepak Patel', 'dfdf', 2, 'Raju', 1, '2024-05-14 01:55:47'),
(48, 1, 'Deepak Patel', 'asdfas', 2, 'Raju', 0, '2024-05-14 01:57:09'),
(49, 1, 'Deepak Patel', 'sada', 2, 'Raju', 0, '2024-05-14 01:57:19'),
(50, 1, 'Deepak Patel', 'asda', 2, 'Raju', 0, '2024-05-14 01:57:33'),
(51, 2, 'Raju', 'sdf', 1, 'Deepak Patel', 0, '2024-05-14 01:57:47'),
(52, 2, 'Raju', 'dddd', 1, 'Deepak Patel', 0, '2024-05-14 01:58:41'),
(53, 1, 'Deepak Patel', 'sdfs', 2, 'Raju', 0, '2024-05-14 01:58:55'),
(54, 2, 'Raju', 'assa', 1, 'Deepak Patel', 0, '2024-05-14 01:59:06'),
(55, 2, 'Raju', 'g', 1, 'Deepak Patel', 0, '2024-05-14 01:59:28'),
(56, 2, 'Raju', 'f', 1, 'Deepak Patel', 0, '2024-05-14 01:59:42'),
(57, 2, 'Raju', 'fgfd', 1, 'Deepak Patel', 0, '2024-05-14 02:00:41'),
(58, 1, 'Deepak Patel', 'sfssds', 2, 'Raju', 0, '2024-05-14 02:00:51'),
(59, 2, 'Raju', 'sfd', 1, 'Deepak Patel', 0, '2024-05-14 02:01:23'),
(60, 1, 'Deepak Patel', 'fgdf', 9, 'demo', 0, '2024-07-02 05:19:59');

-- --------------------------------------------------------

--
-- Table structure for table `log_master`
--

CREATE TABLE `log_master` (
  `log_id` int(11) NOT NULL,
  `log_email` varchar(25) NOT NULL,
  `log_logintime` time NOT NULL,
  `log_logouttime` time NOT NULL,
  `log_workingtime` time NOT NULL,
  `log_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log_master`
--

INSERT INTO `log_master` (`log_id`, `log_email`, `log_logintime`, `log_logouttime`, `log_workingtime`, `log_datetime`) VALUES
(1, 'admin@gmail.com', '16:36:31', '16:37:04', '00:00:33', '2024-04-29 04:37:04'),
(2, 'admin@gmail.com', '16:37:15', '16:37:39', '00:00:24', '2024-04-29 04:37:39'),
(3, 'raju@gmail.com', '16:37:50', '16:37:52', '00:00:02', '2024-04-29 04:37:52'),
(4, 'admin@gmail.com', '16:38:21', '16:41:57', '00:03:36', '2024-04-29 04:41:57'),
(5, 'admin@gmail.com', '16:42:21', '16:51:52', '00:09:31', '2024-04-29 04:51:52'),
(6, 'meet@gmail.com', '16:52:01', '16:52:11', '00:00:10', '2024-04-29 04:52:11'),
(7, 'meet@gmail.com', '16:52:19', '16:52:48', '00:00:29', '2024-04-29 04:52:48'),
(8, 'admin@gmail.com', '16:52:52', '17:00:49', '00:07:57', '2024-04-29 05:00:49'),
(9, 'raju@gmail.com', '17:00:57', '17:03:49', '00:02:52', '2024-04-29 05:03:49'),
(10, 'raju@gmail.com', '17:03:57', '17:13:48', '00:09:51', '2024-04-29 05:13:48'),
(11, 'admin@gmail.com', '17:13:53', '17:57:41', '00:43:48', '2024-04-29 05:57:41'),
(12, 'admin@gmail.com', '17:57:47', '18:11:40', '00:13:53', '2024-04-29 06:11:40'),
(13, 'admin@gmail.com', '18:11:57', '00:00:00', '00:00:00', '2024-04-29 06:11:57'),
(14, 'admin@gmail.com', '10:32:22', '10:34:52', '00:02:30', '2024-04-30 10:34:52'),
(15, 'raju@gmail.com', '10:34:04', '10:35:17', '00:01:13', '2024-04-30 10:35:17'),
(16, 'admin@gmail.com', '10:34:58', '11:05:51', '00:30:53', '2024-04-30 11:05:51'),
(17, 'raju@gmail.com', '10:35:23', '11:00:24', '00:25:01', '2024-04-30 11:00:24'),
(18, 'admin@gmail.com', '11:07:02', '11:11:07', '00:04:05', '2024-04-30 11:11:07'),
(19, 'admin@gmail.com', '11:13:46', '00:00:00', '00:00:00', '2024-04-30 11:13:46'),
(20, 'raju@gmail.com', '11:15:37', '11:27:55', '00:12:18', '2024-04-30 11:27:55'),
(21, 'meet@gmail.com', '16:22:10', '16:22:14', '00:00:04', '2024-04-30 04:22:14'),
(22, 'meet@gmail.com', '16:22:21', '16:44:01', '00:21:40', '2024-04-30 04:44:01'),
(23, 'raju@gmail.com', '16:44:08', '17:42:48', '00:58:40', '2024-04-30 05:42:48'),
(24, 'meet@gmail.com', '17:42:56', '18:06:36', '00:23:40', '2024-04-30 06:06:36'),
(25, 'raju@gmail.com', '18:12:16', '00:00:00', '00:00:00', '2024-04-30 06:12:16'),
(26, 'admin@gmail.com', '10:08:45', '10:08:55', '00:00:10', '2024-05-01 10:08:55'),
(27, 'admin@gmail.com', '10:08:59', '00:00:00', '00:00:00', '2024-05-01 10:08:59'),
(28, 'raju@gmail.com', '11:09:29', '11:09:34', '00:00:05', '2024-05-01 11:09:34'),
(29, 'raju@gmail.com', '11:09:41', '11:54:16', '00:44:35', '2024-05-01 11:54:16'),
(30, 'admin@gmail.com', '11:10:15', '11:55:00', '00:44:45', '2024-05-01 11:55:00'),
(31, 'admin@gmail.com', '11:55:15', '15:57:23', '04:02:08', '2024-05-01 03:57:23'),
(32, 'raju@gmail.com', '11:59:37', '12:22:26', '00:22:49', '2024-05-01 12:22:26'),
(33, 'meet@gmail.com', '12:22:35', '12:52:22', '00:29:47', '2024-05-01 12:52:22'),
(34, 'meet@gmail.com', '13:02:08', '15:42:22', '02:40:14', '2024-05-01 03:42:22'),
(35, 'raju@gmail.com', '15:42:29', '15:43:25', '00:00:56', '2024-05-01 03:43:25'),
(36, 'meet@gmail.com', '15:43:32', '15:53:11', '00:09:39', '2024-05-01 03:53:11'),
(37, 'meet@gmail.com', '15:56:55', '16:13:20', '00:16:25', '2024-05-01 04:13:20'),
(38, 'admin@gmail.com', '15:58:38', '16:03:49', '00:05:11', '2024-05-01 04:03:49'),
(39, 'admin@gmail.com', '16:12:09', '16:15:48', '00:03:39', '2024-05-01 04:15:48'),
(40, 'meet@gmail.com', '16:13:31', '16:15:44', '00:02:13', '2024-05-01 04:15:44'),
(41, 'admin@gmail.com', '16:15:52', '16:16:18', '00:00:26', '2024-05-01 04:16:18'),
(42, 'meet@gmail.com', '16:16:04', '16:57:26', '00:41:22', '2024-05-01 04:57:26'),
(43, 'admin@gmail.com', '16:17:03', '16:18:00', '00:00:57', '2024-05-01 04:18:00'),
(44, 'admin@gmail.com', '16:18:22', '16:57:53', '00:39:31', '2024-05-01 04:57:53'),
(45, 'admin@gmail.com', '10:12:55', '10:15:36', '00:02:41', '2024-05-02 10:15:36'),
(46, 'admin@gmail.com', '10:16:06', '10:37:06', '00:21:00', '2024-05-02 10:37:06'),
(47, 'admin@gmail.com', '10:38:08', '10:39:00', '00:00:52', '2024-05-02 10:39:00'),
(48, 'admin@gmail.com', '10:39:04', '10:39:13', '00:00:09', '2024-05-02 10:39:13'),
(49, 'admin@gmail.com', '10:39:48', '10:40:00', '00:00:12', '2024-05-02 10:40:00'),
(50, 'admin@gmail.com', '10:40:41', '10:42:20', '00:01:39', '2024-05-02 10:42:20'),
(51, 'admin@gmail.com', '10:42:39', '10:42:49', '00:00:10', '2024-05-02 10:42:49'),
(52, 'admin@gmail.com', '10:43:21', '10:47:42', '00:04:21', '2024-05-02 10:47:42'),
(53, 'admin@gmail.com', '10:47:46', '10:47:53', '00:00:07', '2024-05-02 10:47:53'),
(54, 'admin@gmail.com', '10:48:06', '10:49:16', '00:01:10', '2024-05-02 10:49:16'),
(55, 'admin@gmail.com', '10:49:21', '10:49:24', '00:00:03', '2024-05-02 10:49:24'),
(56, 'admin@gmail.com', '10:49:29', '10:49:31', '00:00:02', '2024-05-02 10:49:31'),
(57, 'admin@gmail.com', '10:50:01', '10:50:02', '00:00:01', '2024-05-02 10:50:02'),
(58, 'admin@gmail.com', '10:56:17', '10:57:13', '00:00:56', '2024-05-02 10:57:13'),
(59, 'admin@gmail.com', '10:57:18', '10:57:21', '00:00:03', '2024-05-02 10:57:21'),
(60, 'admin@gmail.com', '10:58:16', '10:58:59', '00:00:43', '2024-05-02 10:58:59'),
(61, 'admin@gmail.com', '10:59:27', '00:00:00', '00:00:00', '2024-05-02 10:59:27'),
(62, 'admin@gmail.com', '11:00:22', '11:08:30', '00:08:08', '2024-05-02 11:08:30'),
(63, 'admin@gmail.com', '11:08:33', '00:00:00', '00:00:00', '2024-05-02 11:08:33'),
(64, 'admin@gmail.com', '11:10:21', '00:00:00', '00:00:00', '2024-05-02 11:10:21'),
(65, 'admin@gmail.com', '11:12:02', '11:12:23', '00:00:21', '2024-05-02 11:12:23'),
(66, 'admin@gmail.com', '11:12:28', '11:24:06', '00:11:38', '2024-05-02 11:24:06'),
(67, 'admin@gmail.com', '11:24:10', '11:25:11', '00:01:01', '2024-05-02 11:25:11'),
(68, 'admin@gmail.com', '11:29:32', '11:31:06', '00:01:34', '2024-05-02 11:31:06'),
(69, 'admin@gmail.com', '11:33:45', '11:33:55', '00:00:10', '2024-05-02 11:33:55'),
(70, 'admin@gmail.com', '11:34:46', '11:35:58', '00:01:12', '2024-05-02 11:35:58'),
(71, 'admin@gmail.com', '11:36:10', '11:46:01', '00:09:51', '2024-05-02 11:46:01'),
(72, 'admin@gmail.com', '11:48:08', '12:11:27', '00:23:19', '2024-05-02 12:11:27'),
(73, 'admin@gmail.com', '12:10:38', '12:10:51', '00:00:13', '2024-05-02 12:10:51'),
(74, 'raju@gmail.com', '12:11:12', '12:37:04', '00:25:52', '2024-05-02 12:37:04'),
(75, 'admin@gmail.com', '12:11:39', '12:32:59', '00:21:20', '2024-05-02 12:32:59'),
(76, 'admin@gmail.com', '12:34:16', '14:24:57', '01:50:41', '2024-05-02 02:24:57'),
(77, 'raju@gmail.com', '12:37:52', '12:53:02', '00:15:10', '2024-05-02 12:53:02'),
(78, 'raju@gmail.com', '12:53:43', '13:09:13', '00:15:30', '2024-05-02 01:09:13'),
(79, 'raju@gmail.com', '13:46:40', '13:51:25', '00:04:45', '2024-05-02 01:51:25'),
(80, 'meet@gmail.com', '13:53:19', '14:13:57', '00:20:38', '2024-05-02 02:13:57'),
(81, 'raju@gmail.com', '14:03:05', '14:07:40', '00:04:35', '2024-05-02 02:07:40'),
(82, 'raju@gmail.com', '14:07:57', '14:15:53', '00:07:56', '2024-05-02 02:15:53'),
(83, 'meet@gmail.com', '14:18:35', '14:31:27', '00:12:52', '2024-05-02 02:31:27'),
(84, 'raju@gmail.com', '14:18:53', '14:57:48', '00:38:55', '2024-05-02 02:57:48'),
(85, 'admin@gmail.com', '14:25:54', '14:27:32', '00:01:38', '2024-05-02 02:27:32'),
(86, 'admin@gmail.com', '14:28:12', '14:32:21', '00:04:09', '2024-05-02 02:32:21'),
(87, 'admin@gmail.com', '14:32:42', '14:40:57', '00:08:15', '2024-05-02 02:40:57'),
(88, 'admin@gmail.com', '17:16:17', '17:23:36', '00:07:19', '2024-05-02 05:23:36'),
(89, 'admin@gmail.com', '19:00:37', '00:00:00', '00:00:00', '2024-05-02 07:00:37'),
(90, 'admin@gmail.com', '10:08:28', '10:55:50', '00:47:22', '2024-05-03 10:55:50'),
(91, 'admin@gmail.com', '10:55:59', '10:57:51', '00:01:52', '2024-05-03 10:57:51'),
(92, 'admin@gmail.com', '10:58:14', '11:02:08', '00:03:54', '2024-05-03 11:02:08'),
(93, 'admin@gmail.com', '11:02:13', '00:00:00', '00:00:00', '2024-05-03 11:02:13'),
(94, 'admin@gmail.com', '11:02:29', '00:00:00', '00:00:00', '2024-05-03 11:02:29'),
(95, 'admin@gmail.com', '11:02:47', '00:00:00', '00:00:00', '2024-05-03 11:02:47'),
(96, 'admin@gmail.com', '11:03:09', '00:00:00', '00:00:00', '2024-05-03 11:03:09'),
(97, 'admin@gmail.com', '11:05:19', '00:00:00', '00:00:00', '2024-05-03 11:05:19'),
(98, 'admin@gmail.com', '11:35:01', '00:00:00', '00:00:00', '2024-05-03 11:35:01'),
(99, 'admin@gmail.com', '11:51:31', '00:00:00', '00:00:00', '2024-05-03 11:51:31'),
(100, 'admin@gmail.com', '11:52:22', '00:00:00', '00:00:00', '2024-05-03 11:52:22'),
(101, 'admin@gmail.com', '12:04:38', '00:00:00', '00:00:00', '2024-05-03 12:04:38'),
(102, 'admin@gmail.com', '12:07:02', '00:00:00', '00:00:00', '2024-05-03 12:07:02'),
(103, 'admin@gmail.com', '12:08:26', '00:00:00', '00:00:00', '2024-05-03 12:08:26'),
(104, 'admin@gmail.com', '12:10:08', '00:00:00', '00:00:00', '2024-05-03 12:10:08'),
(105, 'admin@gmail.com', '12:19:19', '00:00:00', '00:00:00', '2024-05-03 12:19:19'),
(106, 'admin@gmail.com', '12:19:32', '00:00:00', '00:00:00', '2024-05-03 12:19:32'),
(107, 'admin@gmail.com', '12:21:17', '00:00:00', '00:00:00', '2024-05-03 12:21:17'),
(108, 'admin@gmail.com', '12:21:32', '00:00:00', '00:00:00', '2024-05-03 12:21:32'),
(109, 'admin@gmail.com', '12:21:43', '00:00:00', '00:00:00', '2024-05-03 12:21:43'),
(110, 'admin@gmail.com', '12:27:29', '00:00:00', '00:00:00', '2024-05-03 12:27:29'),
(111, 'admin@gmail.com', '12:29:18', '00:00:00', '00:00:00', '2024-05-03 12:29:18'),
(112, 'admin@gmail.com', '12:39:37', '00:00:00', '00:00:00', '2024-05-03 12:39:37'),
(113, 'admin@gmail.com', '12:53:58', '00:00:00', '00:00:00', '2024-05-03 12:53:58'),
(114, 'admin@gmail.com', '13:37:46', '00:00:00', '00:00:00', '2024-05-03 01:37:46'),
(115, 'admin@gmail.com', '13:38:21', '00:00:00', '00:00:00', '2024-05-03 01:38:21'),
(116, 'admin@gmail.com', '14:01:08', '00:00:00', '00:00:00', '2024-05-03 02:01:08'),
(117, 'admin@gmail.com', '14:01:26', '00:00:00', '00:00:00', '2024-05-03 02:01:26'),
(118, 'admin@gmail.com', '14:02:16', '00:00:00', '00:00:00', '2024-05-03 02:02:16'),
(119, 'admin@gmail.com', '14:02:35', '00:00:00', '00:00:00', '2024-05-03 02:02:35'),
(120, 'admin@gmail.com', '14:02:59', '00:00:00', '00:00:00', '2024-05-03 02:02:59'),
(121, 'admin@gmail.com', '14:03:12', '00:00:00', '00:00:00', '2024-05-03 02:03:12'),
(122, 'admin@gmail.com', '14:04:04', '00:00:00', '00:00:00', '2024-05-03 02:04:04'),
(123, 'admin@gmail.com', '14:04:49', '00:00:00', '00:00:00', '2024-05-03 02:04:49'),
(124, 'admin@gmail.com', '14:05:04', '00:00:00', '00:00:00', '2024-05-03 02:05:04'),
(125, 'admin@gmail.com', '14:05:52', '00:00:00', '00:00:00', '2024-05-03 02:05:52'),
(126, 'admin@gmail.com', '14:08:45', '00:00:00', '00:00:00', '2024-05-03 02:08:45'),
(127, 'admin@gmail.com', '14:09:06', '00:00:00', '00:00:00', '2024-05-03 02:09:06'),
(128, 'admin@gmail.com', '14:10:05', '00:00:00', '00:00:00', '2024-05-03 02:10:05'),
(129, 'admin@gmail.com', '14:10:24', '00:00:00', '00:00:00', '2024-05-03 02:10:24'),
(130, 'admin@gmail.com', '14:11:26', '00:00:00', '00:00:00', '2024-05-03 02:11:26'),
(131, 'admin@gmail.com', '14:11:45', '00:00:00', '00:00:00', '2024-05-03 02:11:45'),
(132, 'admin@gmail.com', '14:17:41', '00:00:00', '00:00:00', '2024-05-03 02:17:41'),
(133, 'admin@gmail.com', '14:20:47', '00:00:00', '00:00:00', '2024-05-03 02:20:47'),
(134, 'admin@gmail.com', '14:21:39', '00:00:00', '00:00:00', '2024-05-03 02:21:39'),
(135, 'admin@gmail.com', '14:21:52', '00:00:00', '00:00:00', '2024-05-03 02:21:52'),
(136, 'meet@gmail.com', '14:27:03', '00:00:00', '00:00:00', '2024-05-03 02:27:03'),
(137, 'admin@gmail.com', '14:37:15', '00:00:00', '00:00:00', '2024-05-03 02:37:15'),
(138, 'admin@gmail.com', '14:37:15', '14:38:32', '00:01:17', '2024-05-03 02:38:32'),
(139, 'admin@gmail.com', '14:38:41', '00:00:00', '00:00:00', '2024-05-03 02:38:41'),
(140, 'admin@gmail.com', '14:38:41', '14:38:50', '00:00:09', '2024-05-03 02:38:50'),
(141, 'admin@gmail.com', '14:38:54', '00:00:00', '00:00:00', '2024-05-03 02:38:54'),
(142, 'admin@gmail.com', '14:38:54', '14:45:56', '00:07:02', '2024-05-03 02:45:56'),
(143, 'admin@gmail.com', '14:46:47', '14:46:56', '00:00:09', '2024-05-03 02:46:56'),
(144, 'admin@gmail.com', '14:47:00', '14:49:00', '00:02:00', '2024-05-03 02:49:00'),
(145, 'admin@gmail.com', '14:51:19', '14:51:27', '00:00:08', '2024-05-03 02:51:27'),
(146, 'admin@gmail.com', '14:52:58', '14:53:22', '00:00:24', '2024-05-06 02:53:22'),
(147, 'meet@gmail.com', '14:53:31', '14:53:44', '00:00:13', '2024-05-06 02:53:44'),
(148, 'admin@gmail.com', '15:24:23', '15:28:56', '00:04:33', '2024-05-06 03:28:56'),
(149, 'admin@gmail.com', '15:34:52', '00:00:00', '00:00:00', '2024-05-06 15:34:52'),
(150, 'admin@gmail.com', '15:37:44', '15:38:00', '00:00:16', '2024-05-06 03:38:00'),
(151, 'admin@gmail.com', '15:38:19', '15:40:05', '00:01:46', '2024-05-06 03:40:05'),
(152, 'admin@gmail.com', '15:41:47', '15:42:09', '00:00:22', '2024-05-06 03:42:09'),
(153, 'admin@gmail.com', '15:42:19', '15:43:45', '00:01:26', '2024-05-06 03:43:45'),
(154, 'admin@gmail.com', '16:36:41', '17:04:01', '00:27:20', '2024-05-06 05:04:01'),
(155, 'admin@gmail.com', '11:00:06', '11:17:34', '00:17:28', '2024-05-13 11:17:34'),
(156, 'admin@gmail.com', '11:17:41', '12:25:31', '01:07:50', '2024-05-13 12:25:31'),
(157, 'admin@gmail.com', '11:51:31', '12:52:53', '01:01:22', '2024-05-14 12:52:53'),
(158, 'raju@gmail.com', '12:32:48', '13:17:55', '00:45:07', '2024-05-14 01:17:55'),
(159, 'meet@gmail.com', '12:35:17', '13:14:28', '00:39:11', '2024-05-14 01:14:28'),
(160, 'admin@gmail.com', '12:57:53', '13:32:02', '00:34:09', '2024-05-14 01:32:02'),
(161, 'admin@gmail.com', '13:51:08', '13:59:26', '00:08:18', '2024-05-14 01:59:26'),
(162, 'raju@gmail.com', '13:55:38', '13:58:41', '00:03:03', '2024-05-14 01:58:41'),
(163, 'raju@gmail.com', '13:58:48', '14:00:28', '00:01:40', '2024-05-14 02:00:28'),
(164, 'raju@gmail.com', '13:59:55', '14:00:09', '00:00:14', '2024-05-14 02:00:09'),
(165, 'admin@gmail.com', '14:00:13', '00:00:00', '00:00:00', '2024-05-14 14:00:13'),
(166, 'raju@gmail.com', '14:00:34', '14:05:32', '00:04:58', '2024-05-14 02:05:32'),
(167, 'raju@gmail.com', '14:05:42', '00:00:00', '00:00:00', '2024-05-14 14:05:42'),
(168, 'raju@gmail.com', '14:05:58', '00:00:00', '00:00:00', '2024-05-14 14:05:58'),
(169, 'raju@gmail.com', '14:10:13', '14:10:21', '00:00:08', '2024-05-14 02:10:21'),
(170, 'admin@gmail.com', '14:10:25', '14:10:28', '00:00:03', '2024-05-14 02:10:28'),
(171, 'admin@gmail.com', '14:10:43', '14:17:20', '00:06:37', '2024-05-14 02:17:20'),
(172, 'admin@gmail.com', '14:17:26', '00:00:00', '00:00:00', '2024-05-14 14:17:26'),
(173, 'raju@gmail.com', '14:30:39', '14:37:02', '00:06:23', '2024-05-14 02:37:02'),
(174, 'raju@gmail.com', '14:37:19', '14:46:39', '00:09:20', '2024-05-14 02:46:39'),
(175, 'admin@gmail.com', '18:09:57', '00:00:00', '00:00:00', '2024-05-14 18:09:57'),
(176, 'demo@gmail.com', '09:42:52', '00:00:00', '00:00:00', '2024-05-15 09:42:52'),
(177, 'demo@gmail.com', '09:43:24', '09:58:20', '00:14:56', '2024-05-15 09:58:20'),
(178, 'admin@gmail.com', '09:58:23', '10:55:20', '00:56:57', '2024-05-15 10:55:20'),
(179, 'admin@gmail.com', '10:55:45', '11:17:59', '00:22:14', '2024-05-15 11:17:59'),
(180, 'demo@gmail.com', '11:18:06', '11:35:54', '00:17:48', '2024-05-15 11:35:54'),
(181, 'admin@gmail.com', '11:36:04', '11:36:23', '00:00:19', '2024-05-15 11:36:23'),
(182, 'admin@gmail.com', '16:47:23', '16:58:46', '00:11:23', '2024-05-27 04:58:46'),
(183, 'admin@gmail.com', '17:19:16', '17:19:20', '00:00:04', '2024-07-02 05:19:20'),
(184, 'admin@gmail.com', '17:19:34', '17:20:17', '00:00:43', '2024-07-02 05:20:17'),
(185, 'admin@gmail.com', '17:20:21', '17:20:56', '00:00:35', '2024-07-02 05:20:56'),
(186, 'admin@gmail.com', '18:09:16', '18:09:56', '00:00:40', '2024-07-02 06:09:56'),
(187, 'admin@gmail.com', '13:57:40', '14:07:56', '00:10:16', '2024-07-12 02:07:56');

-- --------------------------------------------------------

--
-- Table structure for table `productgallery_master`
--

CREATE TABLE `productgallery_master` (
  `productgallery_id` int(11) NOT NULL,
  `product_id` int(50) NOT NULL,
  `productgallery_name` varchar(50) NOT NULL,
  `productgallery_status` int(10) NOT NULL,
  `productgallery_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `productgallery_master`
--

INSERT INTO `productgallery_master` (`productgallery_id`, `product_id`, `productgallery_name`, `productgallery_status`, `productgallery_datetime`) VALUES
(2, 1, 'uploads/pg_0.jpg', 0, '2024-04-25 02:33:30'),
(3, 1, 'uploads/pg_1.jpg', 0, '2024-04-25 02:33:30'),
(5, 1, 'uploads/0_6935.jpeg', 1, '2024-04-25 02:42:44'),
(6, 1, 'uploads/1_9963.jpeg', 0, '2024-04-25 02:42:44'),
(7, 1, 'uploads/Product 1_5960.jpeg', 0, '2024-04-25 02:43:38'),
(8, 1, 'uploads/Product 1_5683.jpeg', 0, '2024-04-25 02:43:38');

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

CREATE TABLE `product_master` (
  `product_id` int(11) NOT NULL,
  `category_id` int(25) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_rank` int(10) NOT NULL,
  `product_description` text NOT NULL,
  `product_photo` varchar(50) NOT NULL,
  `product_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`product_id`, `category_id`, `product_name`, `product_rank`, `product_description`, `product_photo`, `product_datetime`) VALUES
(1, 1, 'Product 1', 1, '                                          <p>Product 1<br></p>                                                ', 'uploads/Product 1-1.jpg', '2024-04-25 12:27:05'),
(6, 0, 'raju1', 1, '                     <p>dfdgd s dfg df dfgfd df</p>                        ', 'uploads/raju-1.png', '2024-04-25 04:50:20'),
(8, 5, 'Product 4-1', 1, '<p><br></p>', 'uploads/Product 4-1-5.jpg', '2024-05-13 11:46:42');

-- --------------------------------------------------------

--
-- Table structure for table `schedule_master`
--

CREATE TABLE `schedule_master` (
  `schedule_id` int(11) NOT NULL,
  `admin_email` varchar(25) NOT NULL,
  `schedule_event` varchar(25) NOT NULL,
  `schedule_time` time NOT NULL,
  `schedule_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedule_master`
--

INSERT INTO `schedule_master` (`schedule_id`, `admin_email`, `schedule_event`, `schedule_time`, `schedule_datetime`) VALUES
(1, 'admin@gmail.com', 'Login', '16:36:41', '2024-05-06 16:36:41'),
(2, 'admin@gmail.com', 'Break', '18:51:41', '2024-05-06 16:36:41'),
(3, 'admin@gmail.com', 'Lunch', '20:51:41', '2024-05-06 16:36:41'),
(4, 'admin@gmail.com', 'Tea Break', '00:06:41', '2024-05-06 16:36:41'),
(5, 'admin@gmail.com', 'Logout', '01:36:41', '2024-05-06 16:36:41'),
(6, 'admin@gmail.com', 'Login', '11:00:06', '2024-05-13 11:00:06'),
(7, 'admin@gmail.com', 'Break', '13:15:06', '2024-05-13 11:00:06'),
(8, 'admin@gmail.com', 'Lunch', '15:15:06', '2024-05-13 11:00:06'),
(9, 'admin@gmail.com', 'Tea Break', '18:30:06', '2024-05-13 11:00:06'),
(10, 'admin@gmail.com', 'Logout', '20:00:06', '2024-05-13 11:00:06'),
(11, 'admin@gmail.com', 'Login', '11:51:31', '2024-05-14 11:51:31'),
(12, 'admin@gmail.com', 'Break', '14:06:31', '2024-05-14 11:51:31'),
(13, 'admin@gmail.com', 'Lunch', '16:06:31', '2024-05-14 11:51:31'),
(14, 'admin@gmail.com', 'Tea Break', '19:21:31', '2024-05-14 11:51:31'),
(15, 'admin@gmail.com', 'Logout', '20:51:31', '2024-05-14 11:51:31'),
(16, 'raju@gmail.com', 'Login', '12:32:48', '2024-05-14 12:32:48'),
(17, 'raju@gmail.com', 'Break', '14:47:48', '2024-05-14 12:32:48'),
(18, 'raju@gmail.com', 'Lunch', '16:47:48', '2024-05-14 12:32:48'),
(19, 'raju@gmail.com', 'Tea Break', '20:02:48', '2024-05-14 12:32:48'),
(20, 'raju@gmail.com', 'Logout', '21:32:48', '2024-05-14 12:32:48'),
(21, 'meet@gmail.com', 'Login', '12:35:17', '2024-05-14 12:35:17'),
(22, 'meet@gmail.com', 'Break', '14:50:17', '2024-05-14 12:35:17'),
(23, 'meet@gmail.com', 'Lunch', '16:50:17', '2024-05-14 12:35:17'),
(24, 'meet@gmail.com', 'Tea Break', '20:05:17', '2024-05-14 12:35:17'),
(25, 'meet@gmail.com', 'Logout', '21:35:17', '2024-05-14 12:35:17'),
(26, 'demo@gmail.com', 'Login', '09:42:52', '2024-05-15 09:42:52'),
(27, 'demo@gmail.com', 'Break', '11:57:52', '2024-05-15 09:42:52'),
(28, 'demo@gmail.com', 'Lunch', '13:57:52', '2024-05-15 09:42:52'),
(29, 'demo@gmail.com', 'Tea Break', '17:12:52', '2024-05-15 09:42:52'),
(30, 'demo@gmail.com', 'Logout', '18:42:52', '2024-05-15 09:42:52'),
(31, 'admin@gmail.com', 'Login', '09:58:23', '2024-05-15 09:58:23'),
(32, 'admin@gmail.com', 'Break', '12:13:23', '2024-05-15 09:58:23'),
(33, 'admin@gmail.com', 'Lunch', '14:13:23', '2024-05-15 09:58:23'),
(34, 'admin@gmail.com', 'Tea Break', '17:28:23', '2024-05-15 09:58:23'),
(35, 'admin@gmail.com', 'Logout', '18:58:23', '2024-05-15 09:58:23'),
(36, 'admin@gmail.com', 'Login', '16:47:23', '2024-05-27 16:47:23'),
(37, 'admin@gmail.com', 'Break', '19:02:23', '2024-05-27 16:47:23'),
(38, 'admin@gmail.com', 'Lunch', '21:02:23', '2024-05-27 16:47:23'),
(39, 'admin@gmail.com', 'Tea Break', '00:17:23', '2024-05-27 16:47:23'),
(40, 'admin@gmail.com', 'Logout', '01:47:23', '2024-05-27 16:47:23'),
(41, 'admin@gmail.com', 'Login', '17:19:16', '2024-07-02 17:19:16'),
(42, 'admin@gmail.com', 'Break', '19:34:16', '2024-07-02 17:19:16'),
(43, 'admin@gmail.com', 'Lunch', '21:34:16', '2024-07-02 17:19:16'),
(44, 'admin@gmail.com', 'Tea Break', '00:49:16', '2024-07-02 17:19:16'),
(45, 'admin@gmail.com', 'Logout', '02:19:16', '2024-07-02 17:19:16'),
(46, 'admin@gmail.com', 'Login', '13:57:40', '2024-07-12 13:57:40'),
(47, 'admin@gmail.com', 'Break', '16:12:40', '2024-07-12 13:57:40'),
(48, 'admin@gmail.com', 'Lunch', '18:12:40', '2024-07-12 13:57:40'),
(49, 'admin@gmail.com', 'Tea Break', '21:27:40', '2024-07-12 13:57:40'),
(50, 'admin@gmail.com', 'Logout', '22:57:40', '2024-07-12 13:57:40');

-- --------------------------------------------------------

--
-- Table structure for table `user_master`
--

CREATE TABLE `user_master` (
  `user_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `user_name` varchar(25) NOT NULL,
  `user_email` varchar(25) NOT NULL,
  `user_mobile` varchar(10) NOT NULL,
  `user_role` varchar(10) NOT NULL,
  `user_photo` varchar(25) NOT NULL,
  `user_status` int(10) NOT NULL,
  `user_online` int(11) NOT NULL,
  `user_notification` int(11) NOT NULL,
  `user_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_master`
--

INSERT INTO `user_master` (`user_id`, `admin_id`, `user_name`, `user_email`, `user_mobile`, `user_role`, `user_photo`, `user_status`, `user_online`, `user_notification`, `user_datetime`) VALUES
(1, 1, 'Deepak Patel', 'admin@gmail.com', '123', 'admin', 'uploads/Deepak Patel.png', 1, 0, 1, '2024-05-15 10:52:21'),
(2, 1, 'Raju', 'raju@gmail.com', '123', 'manager', 'uploads/Raju.png', 1, 0, 0, '2024-05-15 10:52:35'),
(8, 1, 'Meet Patel', 'meet@gmail.com', '123', 'manager', 'uploads/Meet Patel.webp', 1, 0, 0, '2024-05-15 10:52:47'),
(9, 1, 'demo', 'demo@gmail.com', '123', 'manager', 'uploads/demo.png', 1, 0, 0, '2024-05-15 10:52:50'),
(10, 1, 'jatan', 'jatan@gmail.com', '123', 'manager', 'uploads/jatan.jpg', 0, 0, 0, '2024-05-27 04:48:49');

-- --------------------------------------------------------

--
-- Table structure for table `websitepages_master`
--

CREATE TABLE `websitepages_master` (
  `websitepages_id` int(11) NOT NULL,
  `category_id` int(25) NOT NULL,
  `websitepages_name` varchar(50) NOT NULL,
  `websitepages_rank` int(10) NOT NULL,
  `websitepages_description` text NOT NULL,
  `websitepages_photo` varchar(50) NOT NULL,
  `websitepages_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `websitepages_master`
--

INSERT INTO `websitepages_master` (`websitepages_id`, `category_id`, `websitepages_name`, `websitepages_rank`, `websitepages_description`, `websitepages_photo`, `websitepages_datetime`) VALUES
(2, 0, 'Our Vision', 2, '                     <p>fgfdgdf gsdfg dffds sfsd s </p>                        ', 'uploads/Our Vision.png', '2024-04-27 04:23:45'),
(3, 0, 'About Us', 1, '<p>sdfdsfdsf sdfdsfsf</p>', 'uploads/About Us.jpg', '2024-04-27 04:25:56'),
(4, 0, 'Our Mission', 3, '<p>dfgfdg df gdfg fd gfdd&nbsp;</p>', 'uploads/Our Mission.png', '2024-04-27 04:26:15');

-- --------------------------------------------------------

--
-- Table structure for table `websitesetting_master`
--

CREATE TABLE `websitesetting_master` (
  `websitesetting_id` int(11) NOT NULL,
  `websitesetting_category` varchar(25) NOT NULL,
  `websitesetting_productgallery` varchar(25) NOT NULL,
  `websitesetting_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `websitesetting_master`
--

INSERT INTO `websitesetting_master` (`websitesetting_id`, `websitesetting_category`, `websitesetting_productgallery`, `websitesetting_datetime`) VALUES
(1, 'yes', 'no', '2024-04-29 11:33:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_master`
--
ALTER TABLE `admin_master`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `category_master`
--
ALTER TABLE `category_master`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `chat_master`
--
ALTER TABLE `chat_master`
  ADD PRIMARY KEY (`chat_id`);

--
-- Indexes for table `log_master`
--
ALTER TABLE `log_master`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `productgallery_master`
--
ALTER TABLE `productgallery_master`
  ADD PRIMARY KEY (`productgallery_id`);

--
-- Indexes for table `product_master`
--
ALTER TABLE `product_master`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `schedule_master`
--
ALTER TABLE `schedule_master`
  ADD PRIMARY KEY (`schedule_id`);

--
-- Indexes for table `user_master`
--
ALTER TABLE `user_master`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `websitepages_master`
--
ALTER TABLE `websitepages_master`
  ADD PRIMARY KEY (`websitepages_id`);

--
-- Indexes for table `websitesetting_master`
--
ALTER TABLE `websitesetting_master`
  ADD PRIMARY KEY (`websitesetting_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_master`
--
ALTER TABLE `admin_master`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `category_master`
--
ALTER TABLE `category_master`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `chat_master`
--
ALTER TABLE `chat_master`
  MODIFY `chat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `log_master`
--
ALTER TABLE `log_master`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=188;

--
-- AUTO_INCREMENT for table `productgallery_master`
--
ALTER TABLE `productgallery_master`
  MODIFY `productgallery_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `product_master`
--
ALTER TABLE `product_master`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `schedule_master`
--
ALTER TABLE `schedule_master`
  MODIFY `schedule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `user_master`
--
ALTER TABLE `user_master`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `websitepages_master`
--
ALTER TABLE `websitepages_master`
  MODIFY `websitepages_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `websitesetting_master`
--
ALTER TABLE `websitesetting_master`
  MODIFY `websitesetting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
