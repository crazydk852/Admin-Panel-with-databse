<?php
include( "sessionmaster.php" );
$action = $_REQUEST[ 'action' ];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>category Details</title>
<?php include("headerscript.php"); ?>
<script type="text/javascript">
function formaction(ID,ID1)
{
	window.location = "category.php?action=set&act="+ ID + "&cate="+ ID1;
}
function formaction1(ID)
{
	window.location = "category.php?action=set&act="+ ID;
}
function confirmDelete(anchor)
{
	var conf = confirm('Are you sure want to delete this record?');
	if(conf)
		window.location=anchor.attr("href");
}
	</script>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <?php
  include( "navbar.php" );
  include( "sidemenu.php" );
  ?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>category Details</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Add New category</li>
            </ol>
          </div>
        </div>
      </div>
    </section>
    <?php if($action == "add") { ?>
    <section class="content">
      <div class="container-fluid">
        <div class="card card-default">
          <div class="card-header">
            <div class="row">
              <div class="col-md-2">
                <a href="category.php?action=list" class="btn btn-block btn-primary"><i class="fa fa-list-ul"></i> View List</a>
              </div>
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <form method="POST" enctype="multipart/form-data">
                  <div class="form-group row">
                    <label class="col-sm-2">category Name</label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="category_name">
                    </div>
                    <label class="col-sm-2">category Rank</label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="category_rank">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-2">category Photo</label>
                    <div class="col-sm-4">
                      <div class="btn btn-default btn-file"> <i class="fas fa-paperclip"></i> Attachment
                        <input type="file" name="category_photo">
                      </div>
                    </div>
                  </div>
                  <div class="form-group row" align="center">
                    <div class="col-sm-12">
                      <input type="submit" name="submit" value="Submit" class="btn btn-primary">
                    </div>
                  </div>
                </form>
                <?php
                if ( isset( $_POST[ 'submit' ] ) == 'submit' ) {
                  $category_name = $_POST[ 'category_name' ];
                  $category_rank = $_POST[ 'category_rank' ];

                  $category_photo = uploadFile( "category_photo", $category_name );
                  $currenttime = date( "Y-m-d h:i:s" );

                  if ( $category_name != "" ) {
                    $check = mysqli_query( $con, "SELECT * FROM category_master WHERE category_name = '" . $category_name . "'" );
                    $row = mysqli_fetch_array( $check );
                    if ( $row >= 1 ) {
                      $message = "This Category Name is Already Exist!";
                      echo "<script type='text/javascript'>alert('$message');</script>";
                    } else {

                      $insert = mysqli_query( $con, "INSERT INTO category_master (category_name, category_rank, category_photo, category_datetime) VALUES ('$category_name', '$category_rank', '$category_photo', '$currenttime')" );

                      if ( $insert ) {
                        echo "<script type='text/javascript'>";
                        echo "window.location='category.php?action=list'";
                        echo "</script>";
                      } else {
                        echo "Error: " . mysqli_error( $con );
                      }
                    }
                  }
                }
                ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <?php } if($action == "list") { ?>
    <section class="content">
      <div class="container-fluid">
        <div class="card card-default">
          <div class="card-header">
            <div class="row">
              <div class="col-md-2">
                <a href="category.php?action=add" class="btn btn-block btn-primary"><i class="fa fa-plus-square"></i> Add new</a>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">DataTable with default features</h3>
            </div>
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Category Name</th>
                    <th>Rank</th>
                    <th>Photo</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $select = mysqli_query( $con, "SELECT * FROM category_master ORDER BY category_id" );
                  while ( $row = mysqli_fetch_array( $select ) ) {
                    ?>
                  <tr>
                    <td><?php echo $row['category_name']; ?></td>
                    <td><?php echo $row['category_rank']; ?></td>
                    <td><img src="<?php echo $row['category_photo']; ?>" width="50" height="50"></td>
                    <td><a href="javascript:formaction(<?php echo '4'; ?>,<?php echo $row['category_id']; ?>)" class="btn btn-block btn-success"><i class="fa fa-eye"></i> View</a></td>
                  </tr>
                  <?php } ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th>Category Name</th>
                    <th>Photo</th>
                    <th>Photo</th>
                    <th>Action</th>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
    <?php } if($action == "view") { ?>
    <section class="content">
      <div class="container-fluid">
        <div class="card card-default">
          <div class="card-header">
            <div class="row">
              <div class="col-md-2">
                <a href="category.php?action=list" class="btn btn-block btn-primary"><i class="fa fa-list-ul"></i> View List</a>
              </div>
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <form method="POST" enctype="multipart/form-data">
                  <?php
                  $select = mysqli_query( $con, "SELECT * FROM category_master where category_id = '$category_id'" );
                  while ( $row = mysqli_fetch_array( $select ) ) {
                    ?>
                  <div class="form-group row">
                    <label class="col-sm-2">category Name</label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" value="<?php echo $row['category_name']; ?>" readonly>
                    </div>
                    <label class="col-sm-2">category Rank</label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" value="<?php echo $row['category_rank']; ?>" readonly>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-2">category Photo</label>
                    <div class="col-sm-4"> <img src="<?php echo $row['category_photo']; ?>" width="150" height="150"> </div>
                  </div>
                  <div class="form-group row" align="center">
                    <div class="col-sm-12"> <a href="javascript:formaction(<?php echo '2'; ?>,<?php echo $row['category_id']; ?>)" class="btn btn-success"><i class="fa fa-edit"></i> Edit Record</a> <a href="javascript:formaction(<?php echo '3'; ?>,<?php echo $row['category_id']; ?>)" class="btn btn-danger"><i class="fa fa-trash-alt"></i> Delete Record</a> </div>
                  </div>
                  <?php } ?>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <?php } if($action == "edit") { ?>
    <section class="content">
      <div class="container-fluid">
        <div class="card card-default">
          <div class="card-header">
            <div class="row">
              <div class="col-md-2">
                <a href="category.php?action=list" class="btn btn-block btn-primary"><i class="fa fa-list-ul"></i> View List</a>
              </div>
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <form method="POST" enctype="multipart/form-data">
                  <?php
                  $select = mysqli_query( $con, "SELECT * FROM category_master where category_id = '$category_id'" );
                  while ( $row = mysqli_fetch_array( $select ) ) {
                    ?>
                  <div class="form-group row">
                    <label class="col-sm-2">category Name</label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="category_name" value="<?php echo $row['category_name']; ?>">
                    </div>
                    <label class="col-sm-2">category Rank</label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="category_rank" value="<?php echo $row['category_rank']; ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-2">category Photo</label>
                    <div class="col-sm-4"> <img src="<?php echo $row['category_photo']; ?>" width="150" height="150">
                      <div class="btn btn-default btn-file"> <i class="fas fa-paperclip"></i> Attachment
                        <input type="file" name="category_photo">
                      </div>
                    </div>
                  </div>
                  <div class="form-group row" align="center">
                    <div class="col-sm-12">
                      <input type="submit" name="submit" value="Update" class="btn btn-primary">
                    </div>
                  </div>
                  <?php } ?>
                </form>
                <?php
                if ( isset( $_POST[ 'submit' ] ) == 'submit' ) {
                  $category_name = $_POST[ 'category_name' ];
                  $category_rank = $_POST[ 'category_rank' ];
                  $category_photo = $_FILES[ 'category_photo' ][ 'name' ];


                  $currenttime = date( "Y-m-d h:i:s" );
                  $availablestauts = 0;

                  $check = mysqli_query( $con, "SELECT * FROM category_master WHERE category_name = '$category_name' AND category_id != '$category_id'" );
                  while ( $row = mysqli_fetch_array( $check ) ) {
                    $availablestauts = 1;
                  }
                  if ( $availablestauts == 0 ) {
                    if ( $category_photo != NULL ) {
                      $categoryphoto = mysqli_query( $con, "select * from category_master where category_id='$category_id'" );
                      $categoryphoto = mysqli_fetch_array( $categoryphoto );

                      if ( $categoryphoto[ 'category_photo' ] != 'noimage.jpg' ) {
                        unlink( "$categoryphoto[category_photo]" );
                      }
                      $category_photo = uploadFile( "category_photo", $category_name );
                      $photoupdate = "UPDATE category_master SET category_photo='$category_photo' WHERE category_id='$category_id'";
                      mysqli_query( $con, $photoupdate );
                    }

                    $update = "UPDATE category_master SET category_name = '$category_name', category_rank = '$category_rank' WHERE category_id = '$category_id'";
                    mysqli_query( $con, $update );

                    echo "<script type='text/javascript'>";
                    echo "window.location='category.php?action=list'";
                    echo "</script>";
                  }
                  if ( $availablestauts == 1 ) {
                    echo '<script type="text/javascript">window.alert("This Category Already exists!")</script>';
                    echo "<script type='text/javascript'>";
                    echo "window.location='category.php?action=list'";
                    echo "</script>";
                  }
                }
                ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <?php
    }
    if ( $action == 'delete' ) {
      $availablestauts = 0;
      $select = mysqli_query( $con, "SELECT * FROM product_master where category_id='$category_id'" );
      while ( $row = mysqli_fetch_array( $select ) ) {
        $availablestauts = 1;
      }

      if ( $availablestauts == 0 ) {
        $sql13 = mysqli_query( $con, "SELECT * FROM category_master WHERE category_id='$category_id'" );
        while ( $row13 = mysqli_fetch_array( $sql13 ) ) {
          $category_photo = $row13[ 'category_photo' ];

          if ( $category_photo != 'noimage.jpg' ) {
            $filePutPath = $category_photo;
            unlink( "$filePutPath" );
          }
        }
        $delete = mysqli_query( $con, "delete from category_master where category_id  = '$category_id'" );
      }
      if ( $availablestauts == 1 ) {
        echo '<script type="text/javascript">window.alert("its already in use")</script>';
      }
      echo "<script type='text/javascript'>";
      echo "window.location='category.php?action=list'";
      echo "</script>";
    }
    if ( $action == 'set' ) {
      $act = $_REQUEST[ 'act' ];
      $actionvalue = "";

      $category_id = $_REQUEST[ 'cate' ];
      if ( $category_id != NULL ) {
        $_SESSION[ 'category_id' ] = $category_id;
      }

      if ( $act == "1" ) {
        echo "<script type='text/javascript'>";
        echo "window.location='category.php?action=add'";
        echo "</script>";
      }
      if ( $act == "2" ) {
        echo "<script type='text/javascript'>";
        echo "window.location='category.php?action=edit'";
        echo "</script>";
      }
      if ( $act == "3" ) {
        echo "<script type='text/javascript'>";
        echo "window.location='category.php?action=delete'";
        echo "</script>";
      }
      if ( $act == "4" ) {
        echo "<script type='text/javascript'>";
        echo "window.location='category.php?action=view'";
        echo "</script>";
      }
      if ( $act == "5" ) {
        echo "<script type='text/javascript'>";
        echo "window.location='category.php?action=list'";
        echo "</script>";
      }

    }
    ?>
  </div>
  <?php include("footer.php"); ?>
</div>
<?php include("footerscript.php"); ?>
</body>
</html>
