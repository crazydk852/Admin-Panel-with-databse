<?php
include( "sessionmaster.php" );
$sender_id = getuseridfromsessionadminemail( $_SESSION[ 'admin_email' ] );
$receiver_id = $_GET[ 'user_id' ];

$removenotification = "UPDATE user_master SET user_notification = '0' WHERE user_id = '$receiver_id'";
mysqli_query( $con, $removenotification );
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Online Members</title>
<?php include("headerscript.php"); ?>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <?php
  include( "navbar.php" );
  include( "sidemenu.php" );
  ?>
  <div class="content-wrapper"><br>
    <section class="content">
      <div class="container-fluid">
        <div class="card direct-chat direct-chat-primary">
          <div class="card-header">
            <h3 class="card-title"><?php echo getusernamefromuserid( $receiver_id ); ?>
              <?php if(getuserstatusfromuserid($receiver_id) == '1') { ?>
              <small style="color: green"><strong>Online</strong></small>
              <?php } else { ?>
              <small style="color: #514F4F"><strong>Offline</strong></small>
              <?php } ?>
            </h3>
            <div class="card-tools"> <a href="deletechat.php?sender_id=<?php echo $sender_id; ?>&receiver_id=<?php echo $receiver_id; ?>" class="btn btn-tool" title="Clear Chat"> <i class="fas fa-trash-alt"></i>Clear Chat</a> </div>
          </div>
          <div class="card-body">
            <div class="direct-chat-messages chat-window" id="chat-window">
              <?php
              $select = mysqli_query( $con, "SELECT * FROM chat_master WHERE (sender_id = '$sender_id' AND receiver_id = '$receiver_id') OR (sender_id = '$receiver_id' AND receiver_id = '$sender_id') ORDER BY chat_datetime" );
              while ( $row = mysqli_fetch_array( $select ) ) {
                $message_side = ( $row[ 'sender_id' ] == $sender_id ) ? 'right' : 'left';
                $username = ( $message_side == 'right' ) ? 'You' : getusernamefromuserid( $receiver_id );
                if ( $message_side == 'right' ) {
                  $user_photo = getuserphotofromuserid( $sender_id );
                } else {
                  $user_photo = getuserphotofromuserid( $receiver_id );
                }
                $timestamp = date( "F j, Y h:i A", strtotime( $row[ 'chat_datetime' ] ) );
                ?>
              <div class="direct-chat-msg <?php echo $message_side; ?>">
                <div class="direct-chat-infos clearfix"> <span class="direct-chat-name float-<?php echo $message_side; ?>"><?php echo $username; ?></span> <span class="direct-chat-timestamp"> <?php echo $timestamp; ?>
                  <?php if ($message_side == 'right') : ?>
                  <a href="deletechat.php?chat_id=<?php echo $row['chat_id']; ?>&receiver_id=<?php echo $receiver_id; ?>" class="delete-message" data-message-id="<?php echo $row['chat_id']; ?>"> <i class="fas fa-trash-alt" title="Delete message"></i> </a>
                  <?php endif; ?>
                  </span> </div>
                <img class="direct-chat-img" src="<?php echo $user_photo; ?>">
                <div class="direct-chat-text">
                  <p><?php echo $row['chat_message']; ?></p>
                </div>
              </div>
              <?php } ?>
            </div>
          </div>
          <div class="card-footer">
            <form method="post">
              <div class="input-group">
                <input type="text" name="chat_message" placeholder="Type Message ..." class="form-control">
                <span class="input-group-append">
                <input type="submit" name="submit" value="Send" class="btn btn-primary">
                </span> </div>
            </form>
            <?php
            if ( isset( $_POST[ 'submit' ] ) == 'submit' ) {
              $chat_message = $_POST[ 'chat_message' ];
              $currenttime = date( "Y-m-d h:i:s" );
              $sender_name = getusernamefromuserid( $sender_id );
              $receiver_name = getusernamefromuserid( $receiver_id );
              $insert = "INSERT INTO chat_master (sender_id, sender_name, chat_message, receiver_id, receiver_name, chat_datetime) VALUES ('$sender_id', '$sender_name', '$chat_message', '$receiver_id', '$receiver_name', '$currenttime')";
              mysqli_query( $con, $insert );

              $sendnotification = "UPDATE user_master SET user_notification = '1' WHERE user_id = '$sender_id'";
              mysqli_query( $con, $sendnotification );

              echo "<script type='text/javascript'>";
              echo "window.location='chat.php?user_id={$receiver_id}'";
              echo "</script>";

            }
            ?>
          </div>
        </div>
      </div>
    </section>
  </div>
  <?php include("footer.php"); ?>
</div>
<script>
setTimeout(function() {
    location.reload();
}, 30000);
</script> 
<script>
function scrollToBottom() {
  var chatWindow = document.getElementById('chat-window');
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

window.onload = scrollToBottom;
</script>
<?php include("footerscript.php"); ?>
</body>
</html>
