<?php 
    error_reporting(0); 
	date_default_timezone_set('Asia/Kolkata');
	$host="localhost";

	if($_SERVER['HTTP_HOST'] == "localhost") {	
		$database="adminlte"; $username="root"; $password="";
	}
	else {	
		$database="sitpladminpanel"; $username="sitpladminpanel"; $password="123456789";
	}
	
	$con = mysqli_connect($host,$username,$password);
	if (!$con) {
	    die('Could not connect : ' . mysqli_error());
	}
	mysqli_select_db($con,$database);
?>