<?php
include( "sessionmaster.php" );
$sender_id = getuseridfromsessionadminemail( $_SESSION[ 'admin_email' ] );
$receiver_id = $_GET[ 'receiver_id' ];
$chat_id = $_GET[ 'chat_id' ];
if ( $chat_id != '' ) {
  $delete = "delete from chat_master where chat_id  = '$chat_id'";
  mysqli_query( $con, $delete );
} else {
  $delete_query = "DELETE FROM chat_master WHERE (sender_id = '$sender_id' AND receiver_id = '$receiver_id') OR (sender_id = '$receiver_id' AND receiver_id = '$sender_id')";
  mysqli_query( $con, $delete_query );
}
echo "<script type='text/javascript'>";
echo "window.location='chat.php?user_id={$receiver_id}'";
echo "</script>";
?>