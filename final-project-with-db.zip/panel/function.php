<?php
include( "config.php" );
// Function to format time
function formatTime( $time ) {
  return str_pad( $time, 2, '0', STR_PAD_LEFT );
}
/*  websitesetting_master function start  */
function getwebsitesettingcategoryfromwebsitesettingid( $websitesetting_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM websitesetting_master WHERE websitesetting_id = '$websitesetting_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'websitesetting_category' ];
  }
}

function getwebsitesettingproductgalleryfromwebsitesettingid( $websitesetting_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM websitesetting_master WHERE websitesetting_id = '$websitesetting_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'websitesetting_productgallery' ];
  }
}
/*  websitesetting_master function end  */

/*  user_master function start  */
function getusernamefromuserid( $user_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM user_master WHERE user_id = '$user_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'user_name' ];
  }
}

function getusernamefromsession( $user_email ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM user_master WHERE user_email = '$user_email'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'user_name' ];
  }
}

function getsueremailfromuserid( $user_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM user_master WHERE user_id = '$user_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'user_email' ];
  }
}

function getuserphotofromuserid( $user_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM user_master WHERE user_id = '$user_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'user_photo' ];
  }
}

function getuserphotofromuseremail( $user_email ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM user_master WHERE user_email = '$user_email'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'user_photo' ];
  }
}

function countonlineusersfromuseremail( $user_email ) {
  global $con;
  $sql = "SELECT COUNT(*) AS online_count FROM user_master WHERE user_online = '1'";
  $result = mysqli_query( $con, $sql );
  $row = mysqli_fetch_assoc( $result );
  $online_count = $row[ 'online_count' ];
  return $online_count;
}

function getuserrolefromuserid( $user_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM user_master WHERE user_id = '$user_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'user_role' ];
  }
}

function uploadprofile123( $inputName, $user_name ) {
  $targetDir = "uploads/";
  $fileExtension = pathinfo( $_FILES[ $inputName ][ "name" ], PATHINFO_EXTENSION );
  $newFileName = $user_name . '.' . $fileExtension;
  $targetFile = $targetDir . $newFileName;
  move_uploaded_file( $_FILES[ $inputName ][ "tmp_name" ], $targetFile );
  return $targetFile;
}

function uploadprofile( $inputName, $user_name ) {
  $targetDir = "uploads/";
  $fileExtension = pathinfo( $_FILES[ $inputName ][ "name" ], PATHINFO_EXTENSION );
  $newFileName = $user_name . '.' . $fileExtension;
  $targetFile = $targetDir . $newFileName;

  // Compressor settings
  $compress = true; // Set to true if you want to compress
  $compressionQuality = 50; // Adjust compression quality (0-100)

  move_uploaded_file( $_FILES[ $inputName ][ "tmp_name" ], $targetFile );
  if ( $compress && in_array( $fileExtension, array( 'jpg', 'jpeg' ) ) ) {
    $image = imagecreatefromjpeg( $targetFile );
    imagejpeg( $image, $targetFile, $compressionQuality );
    imagedestroy( $image );
  }
  return $targetFile;
}

function getuseridfromsessionuserid( $user_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM user_master WHERE user_id = '$user_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'user_id' ];
  }
}

function getuseridfromsessionadminemail( $admin_email ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM user_master WHERE user_email = '$admin_email'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'user_id' ];
  }
}

function getuserstatusfromsessionuseremail( $user_email ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM user_master WHERE user_email = '$user_email'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'user_status' ];
  }
}

function getuseronlinefromsessionuseremail( $user_email ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM user_master WHERE user_email = '$user_email'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'user_online' ];
  }
}

function getuserstatusfromuserid( $receiver_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM user_master WHERE user_id = '$receiver_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'user_online' ];
  }
}
/*  user_master function end  */

/*  log_master function start  */
function getlogworkingtimefromsessionuseremail( $user_email ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT SUM(TIME_TO_SEC(log_workingtime)) AS logworkingtime FROM log_master WHERE DATE(log_datetime) = CURDATE() AND log_email = '$user_email'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'logworkingtime' ];
  }
}
/*  log_master function end  */

/*  admin_master function start  */
function getusernamefromadminid( $admin_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM admin_master WHERE admin_id = '$admin_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'admin_name' ];
  }
}

function getadminrolefromadminid( $admin_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM admin_master WHERE admin_id = '$admin_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'admin_role' ];
  }
}

function getadminidfromsession( $admin_email ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM admin_master WHERE admin_email = '$admin_email'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'admin_id' ];
  }
}

function getadminidfromsessionadminid( $admin_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM admin_master WHERE admin_id = '$admin_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'admin_status' ];
  }
}
/*  admin_master function end  */

/*  category_master function start  */
function getcategorynamefromcategoryid( $category_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM category_master WHERE category_id = '$category_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'category_name' ];
  }
}

function uploadFile( $inputName, $category_name ) {
  $targetDir = "uploads/";
  $fileExtension = pathinfo( $_FILES[ $inputName ][ "name" ], PATHINFO_EXTENSION );
  $newFileName = $category_name . '.' . $fileExtension;
  $targetFile = $targetDir . $newFileName;
  move_uploaded_file( $_FILES[ $inputName ][ "tmp_name" ], $targetFile );
  return $targetFile;
}
/*  category_master function end  */

/*  product_master function start  */
function getproductnamefromproductid( $product_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM product_master WHERE product_id = '$product_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'product_name' ];
  }
}

function uploadproductphoto( $inputName, $product_name, $category_id ) {
  $targetDir = "uploads/";
  $fileExtension = pathinfo( $_FILES[ $inputName ][ "name" ], PATHINFO_EXTENSION );
  $newFileName = $product_name . '-' . $category_id . '.' . $fileExtension;
  $targetFile = $targetDir . $newFileName;
  move_uploaded_file( $_FILES[ $inputName ][ "tmp_name" ], $targetFile );
  return $targetFile;
}
/*  product_master function end  */

/*  websitepages_master function start  */
function getwebsitepagesnamefromwebsitepagesid( $websitepages_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM websitepages_master WHERE websitepages_id = '$websitepages_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'websitepages_name' ];
  }
}

function uploadwebsitepagesphoto( $inputName, $websitepages_name ) {
  $targetDir = "uploads/";
  $fileExtension = pathinfo( $_FILES[ $inputName ][ "name" ], PATHINFO_EXTENSION );
  $newFileName = $websitepages_name . '.' . $fileExtension;
  $targetFile = $targetDir . $newFileName;
  move_uploaded_file( $_FILES[ $inputName ][ "tmp_name" ], $targetFile );
  return $targetFile;
}
/*  websitepages_master function end  */

/*  log_master function start  */
function getlogintimefromlogid( $log_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM log_master WHERE log_id = '$log_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'log_logintime' ];
  }
}

function getlogouttimefromlogid( $log_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM log_master WHERE log_id = '$log_id'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'log_logouttime' ];
  }
}
/*  log_master function end  */

/* chat_master function start */
function getchatnotificationfromreceiverid( $user_id ) {
  global $con;
  $sql = mysqli_query( $con, "SELECT * FROM chat_master WHERE receiver_id = '$user_id' AND chat_notification = '1'" );
  while ( $row = mysqli_fetch_array( $sql ) ) {
    return $row[ 'chat_notification' ];
  }
}

/* chat_master function ens */

?>