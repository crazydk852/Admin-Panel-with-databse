<?php
include( "config.php" );
session_start();
$admin_email = $_SESSION[ "admin_email" ];
$log_id = $_SESSION[ "log_id" ];
$log_logouttime = date( 'H:i:s' );
$currenttime = date( "Y-m-d h:i:s" );

$login_time = $_SESSION[ 'login_time' ];
$current_time = time();
$elapsed_time = $current_time - $login_time;

$hrs = floor( $elapsed_time / 3600 );
$mnt = floor( ( $elapsed_time % 3600 ) / 60 );
$scd = $elapsed_time % 60;

$log_workingtime = sprintf( "%02d:%02d:%02d", $hrs, $mnt, $scd );

$update = "UPDATE log_master SET log_logouttime = '$log_logouttime', log_workingtime = '$log_workingtime', log_datetime = '$currenttime' WHERE log_id = '$log_id'";
mysqli_query( $con, $update );

$update1 = "UPDATE user_master SET user_online = '0' WHERE user_email = '$admin_email'";
mysqli_query( $con, $update1 );

unset( $_SESSION[ "admin_email" ] );
session_destroy();
header( "Location:login.php" );
exit();
?>