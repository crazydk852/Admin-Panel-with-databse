<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <ul class="navbar-nav">
    <li class="nav-item"> <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a> </li>
    <li class="nav-item d-none d-sm-inline-block"> <strong><a class="nav-link"> <span id="elapsed-time"><?php echo 'Working Time: '.formatTime($hours) . ':' . formatTime($minutes) . ':' . formatTime($seconds); ?></span></a></strong> </li>
  </ul>
  <ul class="navbar-nav ml-auto">
    <li class="nav-item"> <a class="nav-link" data-widget="navbar-search" href="#" role="button"> <i class="fas fa-search"></i> </a>
      <div class="navbar-search-block">
        <form class="form-inline">
          <div class="input-group input-group-sm">
            <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
            <div class="input-group-append">
              <button class="btn btn-navbar" type="submit"> <i class="fas fa-search"></i> </button>
              <button class="btn btn-navbar" type="button" data-widget="navbar-search"> <i class="fas fa-times"></i> </button>
            </div>
          </div>
        </form>
      </div>
    </li>
    <li class="nav-item dropdown"> <a class="nav-link" data-toggle="dropdown" href="#"> <i class="far fa-comments"></i> <span class="badge badge-danger navbar-badge"><?php echo countonlineusersfromuseremail($_SESSION[ "admin_email" ]) ?></span> </a>
      <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
        <?php
        $select = mysqli_query( $con, "SELECT * FROM user_master ORDER BY user_online = '1' DESC, user_online ASC" );
        while ( $row = mysqli_fetch_array( $select ) ) {
          $user_online = $row[ 'user_online' ];
        $user_email = $row[ 'user_email' ];
          ?>
        <a href="onlineuser.php" class="dropdown-item">
        <div class="media"> <img src="<?php echo $row['user_photo']; ?>"  style="width: 30px;" class="img-size-50 mr-3 img-circle">
          <div class="media-body">
            <h3 class="dropdown-item-title"> <?php echo $row['user_name']; ?>
              <?php if($user_online == '1') { ?>
              <span class="float-right text-sm text-success"><i class="fas fa-circle"></i></span>
              <?php } else { ?>
              <span class="float-right text-sm text-muted"><i class="fas fa-circle"></i></span>
              <?php } ?>
            </h3>
              <?php if($user_online == '1') { ?><p class="text-sm text-success">Online</p><?php } else { ?><p class="text-sm text-muted">Offline</p><?php } ?>
          </div>
        </div>
        </a>
        <div class="dropdown-divider"></div>
        <?php } ?>
        <a href="onlineuser.php" class="dropdown-item dropdown-footer">See All Members</a> </div>
    </li>
    <li class="nav-item dropdown"> <a class="nav-link" data-toggle="dropdown" href="#"> <i class="far fa-bell"></i> <span class="badge badge-warning navbar-badge">15</span> </a>
      <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right"> <span class="dropdown-item dropdown-header">15 Notifications</span>
        <div class="dropdown-divider"></div>
        <a href="#" class="dropdown-item"> <i class="fas fa-envelope mr-2"></i> 4 new messages <span class="float-right text-muted text-sm">3 mins</span> </a>
        <div class="dropdown-divider"></div>
        <a href="#" class="dropdown-item"> <i class="fas fa-users mr-2"></i> 8 friend requests <span class="float-right text-muted text-sm">12 hours</span> </a>
        <div class="dropdown-divider"></div>
        <a href="#" class="dropdown-item"> <i class="fas fa-file mr-2"></i> 3 new reports <span class="float-right text-muted text-sm">2 days</span> </a>
        <div class="dropdown-divider"></div>
        <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a> </div>
    </li>
    <li class="nav-item"> <a class="nav-link" data-widget="fullscreen" href="#" role="button"> <i class="fas fa-expand-arrows-alt"></i> </a> </li>
    <li class="nav-item"> <a class="nav-link" data-widget="control-sidebar" data-controlsidebar-slide="true" href="#" role="button"> <i class="fas fa-th-large"></i> </a> </li>
  </ul>
</nav>
