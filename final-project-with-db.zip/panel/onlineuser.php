<?php
include( "sessionmaster.php" );
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Online Members</title>
<?php include("headerscript.php"); ?>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <?php
  include( "navbar.php" );
  include( "sidemenu.php" );
  ?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo getusernamefromsession( $_SESSION[ 'admin_email' ] ); ?><small class="text-sm text-success"><strong> Online</strong></small></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Online Members</li>
            </ol>
          </div>
        </div>
      </div>
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <table id="sistable" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Status</th>
                  <th width="20%">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $useremail = $_SESSION[ 'admin_email' ];

                $select = mysqli_query( $con, "SELECT * FROM user_master WHERE user_email != '$useremail' ORDER BY user_online = '1' DESC, user_online ASC" );

                while ( $row = mysqli_fetch_array( $select ) ) {
                  $user_online = $row[ 'user_online' ];
                  $user_email = $row[ 'user_email' ];
                  $user_notification = $row[ 'user_notification' ];
                  ?>
                <tr>
                  <td><img src="<?php echo $row['user_photo']; ?>" width="30" height="30">&nbsp;<?php echo $row['user_name']; ?>
                    <?php if($user_notification == '1'){ ?>
                    <span class="badge badge-danger">New Message</span>
                    <?php } ?></td>
                  <td><?php if($user_online == '1') { ?>
                    <p class="text-sm text-success"><strong>Online</strong></p>
                    <?php } else { ?>
                    <p class="text-sm text-muted"><strong>Offline</strong></p>
                    <?php } ?></td>
                  <?php /*?><td><?php  if ($user_online == '1') { ?> <
                  a href = "chat.php?user_id=<?php echo $row['user_id']; ?>"
                  class = "btn btn-block btn-success" > < i class = "fas fa-comments" > < /i> Chat Now</a >
                    <?php } else { ?>
<p>Not Available</p>
                  <?php } ?></td><?php */?>
                  <td><a href="chat.php?user_id=<?php echo $row['user_id']; ?>" class="btn btn-block btn-success"><i class="fas fa-comments"></i> Chat Now</a></td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  </div>
  <?php include("footer.php"); ?>
</div>
<?php include("footerscript.php"); ?>
<script>
setTimeout(function() {
    location.reload();
}, 30000);
</script>
</body>
</html>
